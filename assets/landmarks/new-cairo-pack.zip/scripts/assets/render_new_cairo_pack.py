"""Build, export and render the New Cairo landmark collection."""
from pathlib import Path
exec(compile(Path(__file__).with_name('build_new_cairo_landmarks.py').read_text(),str(Path(__file__).with_name('build_new_cairo_landmarks.py')),'exec'))
manifest=[];items=SPECS[CITY]
for slug,title,fn in items:
 cur=bpy.data.collections.new(slug);bpy.context.scene.collection.children.link(cur);category='architecture';globals()[fn]()
 record={'id':slug,'name':title,'file':f'models/{slug}.glb','diorama':f'models/{slug}-diorama.glb','preview':f'previews/{slug}.png'}
 for diorama in [True,False]:
  bpy.ops.object.select_all(action='DESELECT')
  for o in cur.objects:o.select_set(diorama or o.get('asset_part')=='architecture')
  bpy.context.view_layer.objects.active=next(o for o in cur.objects if o.select_get())
  bpy.ops.object.duplicate();bpy.ops.object.join();merged=bpy.context.object;merged.name=slug
  bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
  path=R/record['diorama' if diorama else 'file']
  bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_yup=True,export_apply=True)
  merged.data.calc_loop_triangles();record['dioramaTriangles' if diorama else 'triangles']=len(merged.data.loop_triangles)
  if diorama:record['dimensionsBlender']=list(merged.dimensions)
  else:record['bytes']=path.stat().st_size
  bpy.data.objects.remove(merged,do_unlink=True)
 manifest.append(record);cur.hide_render=True;cur.hide_viewport=True
 print('EXPORTED',CITY,slug,record['triangles'],flush=True)
(R/'manifest.json').write_text(json.dumps({'city':CITY,'style':'Pathfindr painted miniature','units':'artistic miniature units; not meters','front':'Blender -Y / glTF +Z','up':'Blender Z / glTF Y','texture':'textures/painted-palette.png','assets':manifest},indent=2,ensure_ascii=False))
cur=bpy.data.collections.new('STUDIO');bpy.context.scene.collection.children.link(cur)
box('Studio floor',(0,0,-.78),(200,200,.25),2,0)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=args.samples;scene.cycles.use_denoising=True
scene.world.color=(.15,.15,.15);scene.render.resolution_x=760;scene.render.resolution_y=760;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
for loc,power,size,color in [((-10,-12,19),2300,10,(1,.84,.72)),((8,-2,14),1700,9,(.65,.87,1)),((0,10,15),2300,8,(.91,.72,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
 for c in list(o.users_collection):c.objects.unlink(o)
 cur.objects.link(o)
bpy.ops.object.camera_add(location=(15,-23,18));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO'
for c in list(cam.users_collection):c.objects.unlink(cam)
cur.objects.link(cam)
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'{CITY}.blend'))
for i,(slug,title,fn) in enumerate(items):
 if args.only and slug not in args.only.split(','):continue
 c=bpy.data.collections[slug];c.hide_render=False;c.hide_viewport=False
 w,d,h=manifest[i]['dimensionsBlender'];target=Vector((0,0,max(1.2,h*.32)))
 cam.location=target+Vector((14,-23,17));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=max(w*1.32,d*1.26,h*1.58)
 scene.render.filepath=str(R/'previews'/f'{slug}.png');bpy.ops.render.render(write_still=True)
 c.hide_render=True;c.hide_viewport=True;print('RENDERED',CITY,slug,flush=True)
for i,(slug,_,_) in enumerate(items):
 c=bpy.data.collections[slug];c.hide_render=False;c.hide_viewport=False
 for o in c.objects:o.location+=Vector(((i%5-2)*24,(i//5)*24,0))
cam.location=(49,-75,88);target=Vector((0,10,1));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=130
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   area.spaces.active.shading.type='SOLID';area.spaces.active.shading.color_type='TEXTURE';area.spaces.active.region_3d.view_perspective='CAMERA'
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'{CITY}.blend'));print('CITY_COMPLETE',CITY,flush=True)
