"""Check final GLB containers, normals, UVs, opaque materials and embedded textures."""
from pathlib import Path
import json,struct,math
ROOT=Path(__file__).resolve().parents[2]/'assets/landmarks'
for city in ['new-cairo']:
 r=ROOT/city;manifest=json.loads((r/'manifest.json').read_text());report=[]
 for p in sorted((r/'models').glob('*.glb')):
  b=p.read_bytes();assert struct.unpack_from('<4sII',b)==(b'glTF',2,len(b)),p
  length,kind=struct.unpack_from('<II',b,12);assert kind==0x4e4f534a;g=json.loads(b[20:20+length]);binary=28+length
  assert len(g['meshes'])==len(g['materials'])==len(g['images'])==1,p
  prim=g['meshes'][0]['primitives'];assert len(prim)==1
  assert all(k in prim[0]['attributes'] for k in ['POSITION','NORMAL','TEXCOORD_0'])
  assert g['materials'][0].get('alphaMode','OPAQUE')=='OPAQUE'
  pos=g['accessors'][prim[0]['attributes']['POSITION']];assert all(math.isfinite(x) for x in pos['min']+pos['max']);assert all(x<y for x,y in zip(pos['min'],pos['max']))
  view=g['bufferViews'][g['images'][0]['bufferView']];start=binary+view.get('byteOffset',0);assert b[start:start+8]==b'\x89PNG\r\n\x1a\n'
  width,height=struct.unpack_from('>II',b,start+16);assert(width,height)==(320,64)
  triangles=g['accessors'][prim[0]['indices']]['count']//3
  report.append({'file':p.name,'triangles':triangles,'bytes':len(b),'meshes':1,'materials':1,'opaque':True,'embeddedTexture':[width,height]})
 assert len(report)==20
 for a in manifest['assets']:
  actual=next(x for x in report if x['file']==Path(a['file']).name)
  assert a['triangles']==actual['triangles'] and a['bytes']==actual['bytes']
  assert (r/a['preview']).exists()
 assert all(x.get('downloaded') and (r/'references'/x['file']).exists() for x in json.loads((r/'references/sources.json').read_text()))
 (r/'validation.json').write_text(json.dumps({'passed':True,'files':report},indent=2))
 print(city,': 20 valid GLBs, 10 renders, all photo references present;',sum(a['triangles'] for a in manifest['assets']),'standalone triangles')
