"""Blender import verification of all twenty delivered GLBs."""
import bpy,json
from pathlib import Path
root=Path(__file__).resolve().parents[2]/'assets/landmarks'
for city in ['new-cairo']:
 result=[]
 for p in sorted((root/city/'models').glob('*.glb')):
  bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
  bpy.ops.import_scene.gltf(filepath=str(p))
  m=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(m)==1,p
  o=m[0];assert len(o.data.uv_layers) and len(o.data.polygons) and len(o.data.materials)==1
  textures=[n for n in o.data.materials[0].node_tree.nodes if n.type=='TEX_IMAGE'];assert len(textures)==1 and tuple(textures[0].image.size)==(320,64)
  result.append({'file':p.name,'imported':True,'embeddedTexture':True})
 assert len(result)==20
 (root/city/'roundtrip-validation.json').write_text(json.dumps(result,indent=2))
 print('IMPORT_PASS',city,flush=True)
