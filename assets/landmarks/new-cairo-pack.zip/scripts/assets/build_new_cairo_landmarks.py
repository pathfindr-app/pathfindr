"""New Cairo miniatures, modeled against photographs in the reference manifest."""
from pathlib import Path
shared=Path(__file__).with_name('build_europe_landmarks.py').read_text()
exec(compile(shared.replace("choices=['london','paris','rome']", "choices=['new-cairo']"),str(Path(__file__).with_name('build_europe_landmarks.py')),'exec'))

def palm(x,y,s=1):
 cyl('Palm trunk',(x,y,1.05*s),.105*s,2.1*s,5,7,.07*s)
 for z in [.5,.9,1.3,1.7]:cyl('Palm trunk collar',(x,y,z*s),.115*s,.06*s,1,7)
 for i in range(7):
  a=i*math.tau/7;c=math.cos(a);q=math.sin(a)
  v=[(x,y,2.05*s),(x+.60*c*s+.19*q*s,y+.60*q*s-.19*c*s,2.32*s),(x+1.15*c*s,y+1.15*q*s,1.85*s),(x+.60*c*s-.19*q*s,y+.60*q*s+.19*c*s,2.32*s),(x+.63*c*s,y+.63*q*s,2.4*s)]
  mesh('Folded palm frond',v,[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(0,3,2,1)],3 if i%2 else 7)
 ico('Palm crown',(x,y,2.12*s),(.18*s,.18*s,.25*s),7)

def plaza(w=14,d=11,water=False):
 global category
 category='environment';box('Display plinth',(0,0,-.32),(w,d,.6),2,.18)
 box('Sandstone paving',(0,0,.01),(w-.18,d-.18,.1),1,.1)
 for i,(x,y) in enumerate([(-w*.4,-d*.36),(w*.4,-d*.36),(-w*.4,d*.36),(w*.4,d*.36)]):
  box('Palm garden',(x,y,.09),(1.65,1.55,.12),7,.15);palm(x,y,.82)
  ico('Bougainvillea',(x+.48,y+.24,.32),(.35,.32,.33),6)
 category='architecture'

def hip(n,x,y,z,w,d,h,sw=5):
 return mesh(n,[(x-w/2,y-d/2,z),(x+w/2,y-d/2,z),(x+w/2,y+d/2,z),(x-w/2,y+d/2,z),(x-w*.28,y-d*.22,z+h),(x+w*.28,y-d*.22,z+h),(x+w*.28,y+d*.22,z+h),(x-w*.28,y+d*.22,z+h)],[(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7),(3,2,1,0)],sw)

def crescent(x,y,z,s=.25):
 # A real open crescent silhouette, extruded in Y.
 v=[];steps=12
 for yy in [y-.025,y+.025]:
  for rr in [s,s*.66]:
   for i in range(steps+1):
    a=math.radians(50+i*260/steps);v.append((x+rr*math.cos(a),yy,z+rr*math.sin(a)))
 k=steps+1;f=[]
 for i in range(steps):f += [(i,i+1,k+i+1,k+i),(2*k+i,3*k+i,3*k+i+1,2*k+i+1),(i,2*k+i,2*k+i+1,i+1),(k+i,k+i+1,3*k+i+1,3*k+i)]
 f += [(0,k,3*k,2*k),(k-1,3*k-1,4*k-1,2*k-1)]
 mesh('Brass crescent',v,f,4)

def minaret(x,y,h=8,flared=False):
 if flared:
  box('Minaret foundation',(x,y,.3),(.85,.85,.6),0)
  cyl('Tapered minaret shaft',(x,y,h*.45),.37,h*.86,0,8,.22)
  cyl('Flared minaret crown',(x,y,h*.90),.23,h*.13,0,8,.66)
  cyl('Crown rim',(x,y,h*.976),.68,.13,4,8)
  for i in range(8):
   a=i*math.tau/8;beam('Minaret vertical seam',(x+.37*math.cos(a),y+.37*math.sin(a),.6),(x+.23*math.cos(a),y+.23*math.sin(a),h*.84),.025,1)
  cyl('Crown finial',(x,y,h+ .15),.04,.30,4,6);crescent(x,y,h+.35,.12)
 else:
  box('Square minaret foot',(x,y,.65),(.95,.95,1.3),0)
  cyl('Octagonal minaret',(x,y,h*.5),.39,h-1,0,8,.31)
  for z in [1.9,3.3,4.7,6.1]:
   if z<h-.8:
    for side in range(4):
     a=side*math.pi/2;before=set(cur.objects);arched_window(0,-.372,z,.13,.77,2);rotate_new(before,a,(x,y,0))
  cyl('Minaret cap',(x,y,h-.35),.32,.65,1,8,.12)
  cyl('Finial',(x,y,h+.1),.035,.35,4,6);crescent(x,y,h+.35,.13)

def glass(x,y,z,w,h,sw=3):
 box('Opaque painted glass',(x,y,z),(w,.045,h),sw,0)

def sign(text,x,y,z,size=.35):
 bpy.ops.object.text_add(location=(x,y,z),rotation=(math.pi/2,0,0));o=bpy.context.object;o.data.body=text;o.data.size=size;o.data.align_x='CENTER';o.data.extrude=.006;o.data.resolution_u=1
 bpy.ops.object.convert(target='MESH');finish(bpy.context.object,'Facade lettering '+text,0)

def sharbatly():
 plaza(15,12)
 box('Mosque terrace',(0,0,.18),(11,8,.28),0)
 box('Prayer hall',(0,.9,1.95),(8.8,4.8,3.5),0)
 # The photographed facade has deep square colonnades, not a wall of invented arches.
 for x in [-4.25,-2.15,0,2.15,4.25]:box('Front colonnade pier',(x,-2.8,1.8),(.4,.52,3.3),0)
 box('Front colonnade roof',(0,-2.25,3.55),(9,2.2,.32),0)
 for x in [-3.2,-1.08,1.08,3.2]:glass(x,-1.525,1.75,1.35,2.1,2)
 for y in [-.2,1.4,2.8]:
  for x in [-4.425,4.425]:
   o=box('Side prayer hall window',(x,y,1.9),(.05,.65,1.5),2,0)
 cyl('Dome drum',(0,.6,3.85),2.15,.8,0,20)
 for i in range(16):
  a=i*math.tau/16;o=box('Drum window',(2.17*math.sin(a),.6-2.17*math.cos(a),3.9),(.23,.035,.48),2,0);o.rotation_euler.z=a
 dome('Gold dome',4.25,2.15,1.7,4,(0,.6))
 for i in range(10):
  a=i*math.tau/10
  pts=[(2.17*math.cos(t)*math.cos(a),.6+2.17*math.cos(t)*math.sin(a),4.25+1.72*math.sin(t)) for t in [j*math.pi/12 for j in range(7)]]
  for j in range(6):beam('Dome rib',pts[j],pts[j+1],.045,1)
 cyl('Dome finial',(0,.6,6.1),.045,.4,4,6);crescent(0,.6,6.42)
 for x in [-4.5,4.5]:
  for y in [-2.9,3.2]:minaret(x,y,8.0 if y<0 else 7.5)


def tantawy():
 plaza(14,12)
 box('Prayer hall',(0,1,1.75),(7,5.6,3.35),0)
 cyl('Mosque drum',(0,1,3.58),2.35,.65,0,20)
 dome('Faceted blue dome',3.9,2.35,1.45,3,(0,1))
 for i in range(12):
  a=i*math.tau/12
  pts=[(2.37*math.cos(t)*math.cos(a),1+2.37*math.cos(t)*math.sin(a),3.9+1.47*math.sin(t)) for t in [j*math.pi/12 for j in range(7)]]
  for j in range(6):beam('Dome pale rib',pts[j],pts[j+1],.07,0)
 cyl('Dome finial',(0,1,5.6),.045,.48,4,6);crescent(0,1,5.94,.17)
 # Free-standing monumental open entry, with true through passage.
 arch('Entrance portal',0,-2.5,.18,2.25,4.0,.8,0,9,.68)
 # Fill above the outer arch so the portal reads as the photographed rectangular frame.
 for i in range(9):
  a=i*math.pi/9;b=(i+1)*math.pi/9
  x0=1.805*math.cos(a);x1=1.805*math.cos(b);z0=3.055+1.805*math.sin(a);z1=3.055+1.805*math.sin(b)
  v=[(x0,-2.9,z0),(x1,-2.9,z1),(x1,-2.9,4.87),(x0,-2.9,4.87),(x0,-2.1,z0),(x1,-2.1,z1),(x1,-2.1,4.87),(x0,-2.1,4.87)]
  mesh('Portal spandrel',v,[(0,1,2,3),(4,7,6,5),(0,4,5,1),(3,2,6,7),(0,3,7,4),(1,5,6,2)],0)
 box('Portal cornice',(0,-2.5,4.98),(3.85,.95,.24),0)
 for x in [-2.6,2.6]:
  arch('Side portico',x,-2.15,.2,1.0,2.5,.3,0,7,.18)
 for x in [-2.65,-1.35,0,1.35,2.65]:arched_window(x,-1.825,.6,.6,1.9,2)
 for x in [-4.3,4.3]:minaret(x,2.35,8.4,True)
 for x in [-3.54,3.54]:
  for y in [0,1.4,2.8]:box('Wall pilaster',(x,y,1.8),(.14,.27,3.2),1,0)


def auc():
 plaza(16,14)
 for x in [-5,5]:
  box('Campus sandstone wing',(x,1,1.75),(3,8,3.4),0)
  for z in [.65,1.2,1.75,2.3,2.85]:box('Striped campus masonry',(x,-3.025,z),(3.02,.05,.13),1,0)
  for y in [-1.8,0,1.8,3.6]:
   o=box('Courtyard screen',(x+ (1.52 if x<0 else -1.52),y,2),(.05,.9,1.35),5,0)
   for z in [1.55,1.85,2.15,2.45]:box('Screen horizontal slat',(o.location.x+(.035 if x<0 else -.035),y,z),(.045,.94,.055),4,0)
 arch('AUC ceremonial gateway',0,4,.15,2.5,3.3,1.2,0,10,.6)
 for x in [-2.5,2.5]:
  box('Gateway pavilion',(x,4,1.9),(1.9,2,3.6),0)
  arched_window(x,2.975,.7,.6,1.5,2)
 box('Gateway crown',(0,4,4.0),(1.4,1.1,1.0),0)
 rose(0,3.43,4.05,.36)
 box('Campus tower',(-5,2.6,4),(2.6,2.4,1.2),0)
 box('Tower shade roof',(-5,2.6,4.8),(3.1,2.9,.22),1)
 for x in [-5.8,-4.2]:box('Tower clerestory', (x,1.375,4.1),(.4,.035,.5),2,0)
 for y in [-3.8,-.8,2]:
  box('Reflecting pool coping',(0,y,.16),(1.7,2.3,.25),0,.06)
  box('Reflecting pool water',(0,y,.30),(1.43,2.03,.025),3,0)
  cyl('Little fountain jet',(0,y,.56),.035,.5,0,6,.02)
 for x in [-2.9,2.9]:
  for y in [-3,-.2,2.5]:box('Campus bench',(x,y,.35),(.48,1.2,.55),0)


def gazebo(x,y,z=.15,s=1):
 cyl('Gazebo floor',(x,y,z),.72*s,.15,1,6)
 for i in range(6):
  a=i*math.tau/6;cyl('Gazebo timber post',(x+.58*s*math.cos(a),y+.58*s*math.sin(a),z+.48*s),.035*s,.96*s,5,6)
 cyl('Gazebo roof',(x,y,z+1.05*s),.88*s,.5*s,5,6,.05*s)

def guc():
 plaza(16,13)
 for x,y,w,d,h in [(-5,1,2.8,6,3.6),(0,3.5,6,2.4,4.8),(5,1.5,2.8,5,3.8)]:
  box('GUC sandstone academic block',(x,y,h/2+.1),(w,d,h),4)
  for z in [1.05,2.1,3.15]:glass(x,y-d/2-.025,z,w*.84,.3,2)
  glass(x,y-d/2-.06,h/2,w*.22,h*.9,3)
  for side in [-1,1]:
   for z in [1.05,2.1,3.15]:box('Campus horizontal glazing',(x+side*(w/2+.025),y,z),(.045,d*.8,.32),2,0)
  box('Flat parapet',(x,y,h+.16),(w+.1,d+.1,.14),0)
 cyl('Circular campus garden',(0,-1.7,.17),3.1,.22,7,24)
 for x,y in [(-1.55,-1.4),(1.55,-1.4),(0,-3)]:gazebo(x,y,.31,.85)
 ring('Garden circular path',(0,-1.7,.3),2.78,.10,1,24)
 for x in [-1.2,1.2]:ico('Garden clipped bush',(x,-3.5,.52),(.38,.38,.35),3)


def petrosport():
 plaza(16,12)
 box('Stadium foundation',(0,0,.13),(13.8,9,.22),1)
 box('Football pitch',(0,0,.29),(9.7,5.4,.08),7,0)
 for i in range(8):box('Mown turf stripe',(-4.25+i*1.21,0,.338),(.60,5.15,.015),3,0)
 for y in [-2.55,2.55]:box('Touch line',(0,y,.355),(9.35,.035,.012),0,0)
 for x in [-4.68,4.68,0]:box('Pitch line',(x,0,.356),(.035,5.1,.012),0,0)
 ring('Center circle',(0,0,.36),.75,.022,0,24)
 for side in [-1,1]:
  x=side*4.15
  for y in [-1.3,1.3]:box('Penalty box line',(x,y,.358),(1.05,.03,.012),0,0)
  box('Penalty area edge',(side*3.63,0,.358),(.03,2.6,.012),0,0)
  for y in [-.6,.6]:beam('Goal upright',(side*4.72,y,.35),(side*4.72,y,1),.055,0)
  beam('Goal crossbar',(side*4.72,-.6,1),(side*4.72,.6,1),.055,0)
  for j in range(4):box('End seating terrace',(side*(5.2+j*.33),0,.38+j*.17),(.42,6.8,.36+j*.34),1,0)
 for side in [-1,1]:
  for j in range(5):
   y=side*(2.9+j*.3);z=.48+j*.22
   box('Grandstand riser',(0,y,z/2+.16),(10.6,.38,z),1,0)
   box('Red seating band',(0,y,z+.20),(10.55,.25,.1),5 if side>0 else 2,0)
  for x in [-4,-2,0,2,4]:box('Grandstand access stair',(x,side*3.5,1.0),(.12,1.5,.06),0,0)
 box('Covered main stand roof',(0,-3.7,2.15),(11,1.9,.16),0)
 for x in [-4.9,-2.5,0,2.5,4.9]:beam('Roof post',(x,-4.35,.2),(x,-4.35,2.12),.1,2)
 for x in [-6.3,6.3]:
  for y in [-4.4,4.4]:
   cyl('Floodlight mast',(x,y,2.9),.065,5.6,2,8)
   box('Floodlight mounting frame',(x,y,5.65),(1.2,.18,.65),2)
   for dx in [-.4,0,.4]:
    for dz in [-.16,.16]:box('Floodlight lens',(x+dx,y-.11,5.65+dz),(.29,.025,.23),9,0)


def fountain_arc(x,y,length=2,h=.8):
 pts=[(x,y-length/2+length*j/8,.32+h*math.sin(math.pi*j/8)) for j in range(9)]
 for i in range(8):beam('Painted fountain arc',pts[i],pts[i+1],.035,0)

def festival():
 plaza(17,13)
 box('Festival retail facade',(0,3,2.1),(12,2.4,3.9),0)
 for x in [-5,-3,-1,1,3,5]:
  for z in [1,2.65]:glass(x,1.775,z,1.05,1.15,2)
  box('Retail sunshade',(x,1.55,1.77),(1.4,.75,.12),0)
 for x in [-5.7,5.7]:
  box('Plaza projecting wing',(x,.2,1.35),(1.8,3.6,2.5),0)
  for y in [-.85,.25,1.3]:box('Wing shop window',(x+(-.92 if x>0 else .92),y,1.3),(.045,.7,1.5),2,0)
 box('Facade accent tower',(2.1,2.8,4.4),(1.1,1,1.2),5)
 clockface(2.1,2.265,4.45,.33)
 box('Fountain basin',(0,-1.7,.17),(8.6,5.2,.25),0,.1)
 box('Mint fountain water',(0,-1.7,.31),(8.3,4.9,.03),3,.04)
 for x in [-3,-2,-1,0,1,2,3]:fountain_arc(x,-1.7,3.3,1.15)
 for x in [-4.7,4.7]:
  for y in [-1.5,-3.6]:gazebo(x,y,.1,.43)


def dusit():
 plaza(15,12)
 box('Hotel main wing',(0,1.7,2.15),(11,3.6,4.1),0)
 hip('Hotel terracotta roof',0,1.7,4.25,11.4,4,.65)
 for x in [-4.35,4.35]:
  box('Entrance tower',(x,-.45,2.6),(2.25,2.5,5),0)
  hip('Entrance tower roof',x,-.45,5.12,2.8,3.05,.45)
  for z in [1,2.2,3.4]:glass(x,-1.715,z,1.3,.65,2)
 for x in [-2.7,-1.35,0,1.35,2.7]:
  for z in [1.4,2.55,3.65]:glass(x,-.125,z,.75,.7,3)
 for x in [-2,2]:box('Porte cochere column',(x,-2,1.65),(.55,.55,3.1),1)
 hip('Entrance canopy',0,-1.4,3.2,5.6,3.25,.38)
 box('Entrance canopy cornice',(0,-1.4,3.2),(5.65,3.3,.16),0)
 box('Urn fountain basin',(0,-3.8,.18),(7.2,1.35,.25),1)
 box('Urn fountain water',(0,-3.8,.315),(6.95,1.12,.02),3,0)
 for x in [-2.4,0,2.4]:
  cyl('Fountain urn foot',(x,-3.8,.55),.22,.4,0,12,.40)
  ico('Sculptural fountain urn',(x,-3.8,1.1),(.5,.48,.65),0)
  cyl('Urn mouth',(x,-3.8,1.58),.24,.13,1,12)
  cyl('Urn dark opening',(x,-3.8,1.65),.17,.015,2,12)


def white():
 plaza(14,12)
 box('WHITE main volume',(-1.5,1.3,2.35),(5.3,4,4.5),0)
 box('WHITE side volume',(3,1.8,1.75),(3.7,3,3.3),0)
 glass(-1.5,-.725,2.65,4.9,3.5,2)
 for x in [-3.85,-3.1,-2.35,-1.6,-.85,-.1,.65]:box('Tall facade fin',(x,-.83,2.65),(.14,.27,3.7),1,0)
 for z in [1.1,2.1,3.2,4.4]:box('Glass floor mullion',(-1.5,-.76,z),(5,.035,.05),4,0)
 glass(3,.275,1.9,3.4,2.45,3)
 for x in [1.5,2.3,3.1,3.9,4.6]:box('Wing mullion',(x,.23,1.9),(.055,.08,2.5),1,0)
 box('Cafe shade canopy',(-1.5,-1.1,1.45),(5.3,1.1,.15),0)
 for x in [-3,-.5,2.3]:
  cyl('Cafe table',(x,-2.4,.59),.4,.1,5,8)
  cyl('Table stem',(x,-2.4,.33),.04,.48,2,6)
  cyl('Parasol pole',(x,-2.4,1),.035,1.9,1,6)
  cyl('Ivory parasol',(x,-2.4,1.98),.78,.3,0,8,.06)
  for dx in [-.55,.55]:box('Cafe stool',(x+dx,-2.4,.3),(.3,.35,.5),2)
 for x in [-4.4,4.5]:
  box('Bougainvillea planter',(x,-2.8,.3),(1,1,.5),0)
  ico('Pink flowering shrub',(x,-2.8,.65),(.55,.55,.5),6)


def katameya():
 plaza(16,12)
 for x in [-4,4]:
  box('Clubhouse cream wing',(x,.5,1.5),(4,4.4,2.8),9)
  hip('Clubhouse tiled roof',x,.5,2.93,4.35,4.75,.7)
  for xx in [x-1.2,x,x+1.2]:
   arched_window(xx,-1.725,.65,.65,1.65,2)
   arch('Clubhouse window frame',xx,-1.75,.62,.69,1.68,.07,0,7,.075)
 box('Central pavilion',(0,1.1,1.9),(4,4,3.6),9)
 glass(0,-.925,1.75,2.7,2.3,3)
 for x in [-1.25,0,1.25]:box('Pavilion glazing bar',(x,-.96,1.75),(.07,.07,2.4),0,0)
 cyl('Skylight drum',(0,1.1,3.86),1.65,.3,0,8)
 cyl('Mint skylight',(0,1.1,4.38),1.65,.75,3,8,.04)
 for i in range(8):
  a=i*math.tau/8;beam('Skylight glazing rib',(1.68*math.cos(a),1.1+1.68*math.sin(a),4),(0,1.1,4.78),.055,0)
 box('Clubhouse terrace',(0,-2.5,.25),(12,1.6,.4),1)
 for x in [-5,-3,3,5]:box('Terrace railing post',(x,-3.25,.75),(.07,.07,.7),2,0)
 for side in [-1,1]:beam('Terrace top rail',(side*2,-3.25,1.08),(side*5.7,-3.25,1.08),.05,2)
 gazebo(-4,-2.3,.48,.8)
 # A small patch of the real green communicates the clubhouse setting.
 cyl('Putting green',(1.8,-3.8,.13),1.65,.15,7,20)
 cyl('Golf pin',(2,-3.7,.85),.025,1.4,0,6)
 mesh('Golf flag',[(2,-3.7,1.55),(2.6,-3.7,1.38),(2,-3.7,1.18)],[(0,1,2)],5)


def point90():
 plaza(15,12)
 box('Mall rear volume',(0,1.1,1.9),(10,4,3.6),0)
 # Sweeping photographed blue facade, intentionally faceted into ten glass bays.
 for i in range(10):
  x0=-3.8+i*.76;x1=x0+.76
  def yy(x):return -1.9+.038*x*x
  v=[(x0,yy(x0),1.5),(x1,yy(x1),1.5),(x1,yy(x1),4.6),(x0,yy(x0),4.6)]
  mesh('Curved mint glass bay',v,[(0,1,2,3)],3 if i%3 else 2)
  beam('Curved facade mullion',v[0],v[3],.045,0)
  for z in [2.3,3.1,3.9]:beam('Glass horizontal mullion',(x0,yy(x0)-.01,z),(x1,yy(x1)-.01,z),.035,1)
  mesh('Sweeping roof fascia',[(x0,yy(x0)-.22,4.65),(x1,yy(x1)-.22,4.65),(x1,2.9,4.65),(x0,2.9,4.65),(x0,yy(x0)-.22,4.82),(x1,yy(x1)-.22,4.82),(x1,2.9,4.82),(x0,2.9,4.82)],[(0,1,5,4),(4,5,6,7),(1,2,6,5),(2,3,7,6),(3,0,4,7),(3,2,1,0)],0)
 for x in [-4.5,4.5]:box('Concrete end pier',(x,-.3,2.4),(1.4,3,4.65),1)
 sign('POINT90',4.5,-1.835,3.1,.23)
 for x in [-3,-1.5,0,1.5,3]:glass(x,-.925,.8,1.15,1.3,2)
 box('Entrance canopy',(0,-2.25,1.4),(7.7,1.1,.14),0)
 for x in [-3.5,3.5]:box('Canopy column',(x,-2.55,.75),(.12,.12,1.4),1)
 for x in [-3,3]:
  box('Raised arrival planter',(x,-3.7,.26),(2,1,.4),2)
  ico('Arrival greenery',(x,-3.7,.58),(.75,.4,.35),3)

SPECS={'new-cairo':[
 ('hassan-sharbatly-mosque','Hassan Sharbatly Mosque','sharbatly'),
 ('mosheer-tantawy-mosque','Mosheer Tantawy Mosque','tantawy'),
 ('auc-new-cairo','AUC · New Cairo Campus','auc'),
 ('german-university','German University in Cairo','guc'),
 ('petrosport-stadium','Petrosport Stadium','petrosport'),
 ('cairo-festival-city','Cairo Festival City','festival'),
 ('dusit-thani','Dusit Thani LakeView','dusit'),
 ('white-waterway','WHITE · The Waterway','white'),
 ('katameya-heights','Katameya Heights Clubhouse','katameya'),
 ('point-90','Point 90 Mall','point90')
]}
