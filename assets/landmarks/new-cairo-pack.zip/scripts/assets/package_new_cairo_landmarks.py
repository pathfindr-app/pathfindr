"""Package the reviewed New Cairo collection and traceable photographic references."""
from pathlib import Path
import json,zipfile
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[2];r=ROOT/'assets/landmarks/new-cairo'
m=json.loads((r/'manifest.json').read_text());assets=m['assets']
keys=['mosque','tantawy','auc','guc','petrosport','festival','dusit','waterway2','katameya','point90']
notes=[
 'Four slender octagonal minarets, gold segmented dome, windowed drum and deep rectangular front colonnade.',
 'Two flared minaret crowns, mint ribbed dome and monumental entry portal; simplified prayer hall.',
 'Abbreviated ceremonial courtyard: striped stone wings, central arched gateway, raised tower and linear reflecting pools.',
 'Abbreviated academic campus: warm rectangular blocks, horizontal glass strips and circular garden with small gazebos.',
 'Rectangular football pitch, red seating tiers, a covered main stand and four floodlight masts.',
 'Fountain plaza with a repeated line of arcing jets and abbreviated cream retail facades.',
 'Arrival facade with twin squat towers, terracotta roof canopies and three sculptural urn fountains.',
 'Representative WHITE retail frontage: tall glass bays, vertical fins, cafe canopy and parasol terrace.',
 'Clubhouse front: cream pavilions, tiled roofs, arched windows, central glazed skylight and putting green.',
 'Sweeping faceted blue-glass frontage, concrete end piers, overhanging curved roof and arrival canopy.'
]
raw=json.loads((r/'references/sources.json').read_text());bykey={a.get('referenceKey',a['id']):a for a in raw};sources=[]
for a,k,note in zip(assets,keys,notes):
 a['referenceFeatures']=note;a['photoReference']='references/'+bykey[k]['file']
 source=dict(bykey[k]);source.update(id=a['id'],referenceKey=k,name=a['name'],observedFeatures=note,use='Visual modeling reference only. Original photo pixels are not used in the game textures.');sources.append(source)
(r/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False));(r/'references/sources.json').write_text(json.dumps(sources,indent=2,ensure_ascii=False))
font='/System/Library/Fonts/Supplemental/Arial.ttf';large=ImageFont.truetype(font,39);small=ImageFont.truetype(font,18);label=ImageFont.truetype(font,20)
tris=sum(a['triangles'] for a in assets);mb=sum(a['bytes'] for a in assets)/1048576
out=Image.new('RGB',(2000,1060),'#121925');d=ImageDraw.Draw(out)
d.text((38,25),'NEW CAIRO',font=large,fill='#ecdfca');d.text((39,76),f'PATHFINDR / 10 PHOTO-REFERENCED MINIATURES / {tris:,} TRIANGLES TOTAL',font=small,fill='#9cc8c2')
for i,a in enumerate(assets):
 x=20+i%5*396;y=125+i//5*455;im=Image.open(r/a['preview']).convert('RGB').resize((384,384),Image.Resampling.LANCZOS);out.paste(im,(x,y));d.text((x+6,y+389),a['name'],font=label,fill='#ecdfca');d.text((x+6,y+418),f"{a['triangles']:,} tris / GLB + Blender",font=small,fill='#9bb1bc')
out.save(r/'previews/contact-sheet.jpg',quality=94)
board=Image.new('RGB',(2000,980),'#18232e');draw=ImageDraw.Draw(board)
draw.text((25,20),'NEW CAIRO / REAL PHOTO REFERENCES',font=large,fill='#ecdfca')
for i,a in enumerate(sources):
 x=20+i%5*396;y=100+i//5*430;im=Image.open(r/'references'/a['file']);im.thumbnail((384,360));board.paste(im,(x+(384-im.width)//2,y+(360-im.height)//2));draw.text((x,y+369),a['name'],font=small,fill='#ecdfca')
board.save(r/'references/photo-board.jpg',quality=92)
(r/'README.md').write_text(f'''# New Cairo — Pathfindr landmark miniatures

Ten original Blender models based on the real photos in `references/`. Warm sandstone, slate, mint glass and water, brass, terracotta and small palms extend the DC and Europe painted ceramic aesthetic. The original 320 × 64 paint atlas contains no photographic pixels.

## Files

- `new-cairo.blend`: editable source, ten named collections arranged in two rows, separate studio.
- `models/<id>.glb`: standalone landmark, without the removable display plinth and decorative corner gardens.
- `models/<id>-diorama.glb`: landscaped display version.
- `textures/painted-palette.png`: embedded in every GLB and packed into Blender.
- `previews/contact-sheet.jpg`: all ten models; individual previews alongside it.
- `references/photo-board.jpg` and `sources.json`: actual photos, source pages and features used.
- `manifest.json`: geometry counts, sizes, orientation and reference notes.
- `validation.json` and `roundtrip-validation.json`: GLB checks and Blender reimport results.

## Geometry and mobile use

Standalone collection: **{tris:,} triangles / {mb:.2f} MiB**. Each GLB is one mesh and one opaque material with UVs and an embedded tiny texture. Glass, pools and fountain jets use opaque painted geometry. No alpha blending or external texture requests are needed.

These are asset measurements, not phone frame-rate benchmarks. This pack has not been integrated into the live game or profiled on a device. There are no distance LODs or collision meshes. Share the atlas material during integration if many landmarks are loaded together.

## Scope and coordinates

The collection represents New Cairo, including its campus, sports and leisure destinations. Campus and resort models abbreviate larger complexes into recognizable vignettes. WHITE represents a photographed retail frontage, not the entire Waterway development. Monument silhouettes and colors are stylized, not survey reconstructions.

GLB is Y-up, front +Z; Blender is Z-up, front -Y. Origins are at local ground center. Units are artistic miniature units, not meters. Set scale and heading during map integration. Manifest dimensions describe the landscaped Blender model. The removable display base extends below zero. Actual landmark features such as fountain pools, stadium turf and the campus garden remain in the standalone model.

## Landmarks

'''+ '\n'.join(f"- **{a['name']}** — {a['referenceFeatures']}" for a in assets)+'''

## Rebuild

Place the included `scripts/assets/` directory beside `assets/`. Run Blender headlessly from the project root:

```sh
/path/to/Blender --background --python scripts/assets/render_new_cairo_pack.py -- --city new-cairo
```

The New Cairo builder reuses geometry and atlas helpers from `build_europe_landmarks.py`; all required source scripts are included. Packaging and reference boards use Pillow. Rebuilding replaces the selected pack's generated models and previews. Reference photos remain owned by their original creators and are supplied for modeling review, not as game textures or redistribution-ready game content.
''')
used={a['file'] for a in sources}|{'sources.json','photo-board.jpg'}
for p in (r/'references').iterdir():
 if p.is_file() and p.name not in used:p.unlink()
for p in r.glob('*.blend1'):p.unlink()
zip_path=r.parent/'new-cairo-pack.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in r.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(r.parent))
 for name in ['build_europe_landmarks.py','build_new_cairo_landmarks.py','render_new_cairo_pack.py','package_new_cairo_landmarks.py','validate_new_cairo_pack.py','roundtrip_new_cairo_pack.py','refine_new_cairo_asset.py']:
  p=ROOT/'scripts/assets'/name;z.write(p,'scripts/assets/'+name)
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print(json.dumps({'landmarks':10,'standaloneTriangles':tris,'GLBMiB':round(mb,2),'zipMiB':round(zip_path.stat().st_size/1048576,2),'minTriangles':min(a['triangles'] for a in assets),'maxTriangles':max(a['triangles'] for a in assets)},indent=2))
