"""Photo-referenced London, Paris and Rome miniature geometry.
Use render_europe_pack.py as the Blender entry point.
"""
import bpy, math, random, json, sys, argparse
from pathlib import Path
from mathutils import Vector
parser=argparse.ArgumentParser()
parser.add_argument('--city',choices=['london','paris','rome'],required=True)
parser.add_argument('--only',default='')
parser.add_argument('--samples',type=int,default=16)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
CITY=args.city
R = Path(__file__).resolve().parents[2] / 'assets/landmarks' / CITY
for folder in ['models','textures','previews','references']:(R/folder).mkdir(parents=True,exist_ok=True)
random.seed(92)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
 if c.name != 'Collection': bpy.data.collections.remove(c)
# One UV atlas with ten subtly mottled paint swatches. Original texture, no photo pixels.
colors=['e8dcca','c4bcae','425268','81b5ac','d7b37b','c87e70','e7b4cb','294338','29323f','f5deb0']
N=320; tile=32
im=bpy.data.images.new('Pathfindr_PaintedPalette',width=N,height=64,alpha=True)
pixels=[]
for y in range(64):
 for x in range(N):
  c=colors[x//tile]; rgb=[int(c[i:i+2],16)/255 for i in (0,2,4)]
  grain=random.uniform(-.018,.018)+.012*math.sin(x*.7+y*.34)+.012*math.sin(y*.15)
  pixels.extend([max(0,min(1,v+grain)) for v in rgb]+[1])
im.pixels=pixels; im.filepath_raw=str(R/'textures/painted-palette.png'); im.file_format='PNG'; im.save(); im.pack()
mat=bpy.data.materials.new('Pathfindr | matte painted ceramic'); mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF'); bs.inputs['Roughness'].default_value=.83
tex=mat.node_tree.nodes.new('ShaderNodeTexImage'); tex.image=im; tex.interpolation='Linear'; mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
cur=None
category="architecture"

def finish(o,n,sw=0):
 o.name=n
 o['asset_part']=category
 for c in list(o.users_collection): c.objects.unlink(o)
 cur.objects.link(o)
 if o.type=='MESH':
  o.data.materials.clear(); o.data.materials.append(mat)
  uv=o.data.uv_layers.active or o.data.uv_layers.new(name='PaintUV')
  for p in o.data.polygons:
   # Project each face onto its two dominant axes, staying inside its palette cell.
   axes=sorted(range(3),key=lambda i:abs(p.normal[i]))[:2]
   for li in p.loop_indices:
    co=o.data.vertices[o.data.loops[li].vertex_index].co
    uv.data[li].uv=((sw+ .12+.76*(co[axes[0]]*.19%1))/10,.12+.76*(co[axes[1]]*.19%1))
 return o

def box(n,loc,dim,sw=0,bevel=.035):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.dimensions=dim
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  m=o.modifiers.new('Soft chipped edges','BEVEL'); m.width=bevel; m.segments=1
  bpy.ops.object.modifier_apply(modifier=m.name)
 return finish(o,n,sw)
def cyl(n,loc,r,h,sw=0,verts=12,r2=None):
 bpy.ops.mesh.primitive_cone_add(vertices=verts,radius1=r,radius2=r if r2 is None else r2,depth=h,location=loc)
 return finish(bpy.context.object,n,sw)
def ico(n,loc,scale,sw=0):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=loc); o=bpy.context.object; o.scale=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); return finish(o,n,sw)
def mesh(n,v,f,sw=0):
 me=bpy.data.meshes.new(n); me.from_pydata(v,[],f); me.update(); o=bpy.data.objects.new(n,me); cur.objects.link(o); return finish(o,n,sw)
def roof(n,x,y,z,w,d,h,sw=2):
 return mesh(n,[(x-w/2,y-d/2,z),(x+w/2,y-d/2,z),(x+w/2,y+d/2,z),(x-w/2,y+d/2,z),(x,y-d/2,z+h),(x,y+d/2,z+h)],[(0,1,4),(3,5,2),(0,4,5,3),(1,2,5,4),(0,3,2,1)],sw)
def dome(n,z,r,h,sw=0,xy=(0,0)):
 seg=20; rings=7; vs=[]
 for j in range(rings+1):
  t=(math.pi/2)*j/rings
  for i in range(seg):
   a=i*math.tau/seg; vs.append((xy[0]+r*math.cos(t)*math.cos(a),xy[1]+r*math.cos(t)*math.sin(a),z+h*math.sin(t)))
 fs=[]
 for j in range(rings):
  for i in range(seg):
   a=j*seg+i;b=j*seg+(i+1)%seg;fs.append((a,b,b+seg,a+seg))
 fs.append(tuple(reversed(range(seg))));return mesh(n,vs,fs,sw)
def col(x,y,z,h,r=.18):
 cyl('Column shaft',(x,y,z+h/2),r,h,0,8,r*.85)
 box('Column capital',(x,y,z+h),(.50,.50,.14),0,.01)
 box('Column foot',(x,y,z),(.48,.48,.15),1,.01)
def steps(w,d=3,y=-4,n=6,z=.35):
 for i in range(n):box('Broad stone steps',(0,y+i*.20,z+i*.11),(w-i*.13,d-i*.35,.18),1,.025)
def windows(w,y,z,rows=2,n=9):
 for j in range(rows):
  for i in range(n):
   x=-w/2+(i+.5)*w/n
   box('Window ivory surround',(x,y,z+j*.95),(.43,.09,.68),0,.01)
   box('Recessed warm window',(x,y-.055,z+j*.95),(.31,.035,.53),2 if i%3 else 9,.006)
   box('Window mullion',(x,y-.079,z+j*.95),(.035,.025,.53),1,0)
def tree(x,y,s=1,pink=True):
 cyl('Cherry trunk',(x,y,.55*s),.09*s,1.1*s,5,6)
 for dx,dy,dz,r in [(-.27,0,1.3,.55),(.27,.07,1.48,.63),(0,-.25,1.75,.58)]:
  ico('Cherry blossom' if pink else 'Faceted foliage',(x+dx*s,y+dy*s,dz*s),(r*s,r*s,r*s),6 if pink else 3)
def base(w=14,d=11):
 global category
 category="environment"
 box('Removable display plinth',(0,0,-.32),(w,d,.6),2,.2)
 box('Garden ground',(0,0,.025),(w-.25,d-.25,.12),7,.12)
 box('Entry path',(0,-d*.30,.10),(2.5,d*.38,.08),1,.04)
 for x,y in [(-w*.4,-d*.30),(w*.4,-d*.30),(-w*.4,d*.32),(w*.4,d*.32)]:tree(x,y,.8)
 category="architecture"
def flag(x,y,z):
 cyl('Flag pole',(x,y,z+.75),.027,1.5,4,6)
 box('Flag',(x+.29,y,z+1.23),(.58,.025,.34),0,0)
 for j in range(3):box('Flag stripe',(x+.29,y-.016,z+1.1+j*.11),(.58,.012,.045),5,0)
 box('Flag canton',(x+.12,y-.027,z+1.30),(.24,.012,.18),2,0)
def figure(x,y,z,s=1,seated=False):
 box('Sculpted torso',(x,y,z+1.0*s),(.65*s,.40*s,.85*s),0,.12*s)
 ico('Sculpted head',(x,y-.02*s,z+1.65*s),(.24*s,.23*s,.3*s),0)
 if seated:
  box('Chair',(x,y+.15*s,z+.7*s),(1*s,.6*s,1.2*s),1,.04)
  for dx in [-.24,.24]:box('Seated legs',(x+dx*s,y-.28*s,z+.36*s),(.25*s,.6*s,.65*s),0,.04)
 else:box('Sculpted lower body',(x,y,z+.37*s),(.55*s,.4*s,.7*s),0,.04)
 for dx,rot in [(-.21,-.25),(.21,.25)]:
  o=box('Folded arm',(x+dx*s,y-.27*s,z+1.04*s),(.48*s,.18*s,.20*s),0,.035);o.rotation_euler.y=rot

# Low-cost architectural vocabulary: real openings, faceted curves and baked paint.
def beam(n,a,b,w=.08,sw=0):
 a,b=Vector(a),Vector(b);o=box(n,(a+b)/2,(w,w,(b-a).length),sw,0)
 o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o

def arch(n,x,y,z,w,h,depth=.25,sw=0,segments=6,t=.18):
 """True open arch in XZ, with straight jambs; z is bottom."""
 rad=w/2;spring=z+h-rad
 for dx in [-rad-t/2,rad+t/2]:box(n+' pier',(x+dx,y,(z+spring)/2),(t,depth,spring-z),sw,0)
 vs=[]
 for yy in [y-depth/2,y+depth/2]:
  for rr in [rad,rad+t]:
   for i in range(segments+1):
    a=i*math.pi/segments;vs.append((x+rr*math.cos(a),yy,spring+rr*math.sin(a)))
 k=segments+1;fs=[]
 for i in range(segments):
  fs.extend([(i,i+1,k+i+1,k+i),(2*k+i,3*k+i,3*k+i+1,2*k+i+1),(i,2*k+i,2*k+i+1,i+1),(k+i,k+i+1,3*k+i+1,3*k+i)])
 fs.extend([(0,k,3*k,2*k),(k-1,3*k-1,4*k-1,2*k-1)])
 return mesh(n+' arch',vs,fs,sw)

def arched_window(x,y,z,w=.5,h=1,sw=2,pointed=False):
 if pointed:
  box('Lancet glass',(x,y,z+h*.38),(w,.045,h*.76),sw,0);roof('Pointed glass',x,y,z+h*.76,w,.045,h*.24,sw)
 else:
  r=w/2;vs=[(x-w/2,y,z),(x+w/2,y,z)]
  for i in range(9):
   a=i*math.pi/8;vs.append((x+r*math.cos(a),y,z+h-r+r*math.sin(a)))
  mesh('Arched inset glass',vs,[tuple(range(len(vs)))],sw)

def ring(n,loc,r,t=.08,sw=0,segments=32,vertical=False):
 bpy.ops.mesh.primitive_torus_add(major_segments=segments,minor_segments=4,major_radius=r,minor_radius=t,location=loc)
 o=bpy.context.object
 if vertical:o.rotation_euler.x=math.pi/2
 return finish(o,n,sw)

def annulus(n,z,outer,inner,h=.2,sw=0,segments=32,sy=1):
 vs=[]
 for zz,rr in [(z,outer),(z,inner),(z+h,outer),(z+h,inner)]:
  for i in range(segments):a=i*math.tau/segments;vs.append((rr*math.cos(a),sy*rr*math.sin(a),zz))
 fs=[];nseg=segments
 for i in range(nseg):
  j=(i+1)%nseg
  fs.extend([(i,j,j+2*nseg,i+2*nseg),(i+nseg,i+3*nseg,j+3*nseg,j+nseg),(i+2*nseg,j+2*nseg,j+3*nseg,i+3*nseg),(i,j,j+nseg,i+nseg)])
 return mesh(n,vs,fs,sw)

def rotate_new(before,angle,translation=(0,0,0)):
 c,s=math.cos(angle),math.sin(angle)
 for o in set(cur.objects)-before:
  x,y=o.location.x,o.location.y;o.location.x=c*x-s*y+translation[0];o.location.y=s*x+c*y+translation[1];o.location.z+=translation[2];o.rotation_euler.z+=angle
  # Mesh-authored primitives store absolute coordinates, so rotate about origin as object transform.

def front_windows(w,d,z,rows=2,n=8,x0=0,y0=0):
 for side in range(4):
  span=w if side%2==0 else d;depth=d if side%2==0 else w;count=n if side%2==0 else max(2,round(n*d/w))
  angle=side*math.pi/2
  for j in range(rows):
   for i in range(count):
    xx=-span/2+(i+.5)*span/count;yy=-depth/2-.025
    x=xx*math.cos(angle)-yy*math.sin(angle)+x0;y=xx*math.sin(angle)+yy*math.cos(angle)+y0
    o=box('Painted window',(x,y,z+j*.85),(.29,.045,.48),2 if (i+j)%4 else 9,0);o.rotation_euler.z=angle

def cross(x,y,z,s=.5,sw=4):
 beam('Cross upright',(x,y,z),(x,y,z+s),.055,sw);beam('Cross arms',(x-s*.25,y,z+s*.65),(x+s*.25,y,z+s*.65),.055,sw)

def rose(x,y,z,r=.65):
 ring('Rose stone frame',(x,y,z),r,.07,0,16,True)
 o=cyl('Rose glass',(x,y+.02,z),r*.92,.04,2,16);o.rotation_euler.x=math.pi/2
 for i in range(8):
  a=i*math.tau/8;beam('Rose radial tracery',(x,y-.06,z),(x+r*.89*math.cos(a),y-.06,z+r*.89*math.sin(a)),.045,4)

def crenels(x,y,z,w,d,sw=0):
 for i in range(max(3,int(w/.45))):
  xx=x-w/2+.17+i*(w-.34)/(max(3,int(w/.45))-1)
  for yy in [y-d/2,y+d/2]:box('Battlement tooth',(xx,yy,z),(.22,.24,.31),sw,0)

def clockface(x,y,z,r=.5,angle=0):
 before=set(cur.objects)
 ring('Clock gilt frame',(0,-.08,0),r,.065,4,20,True)
 o=cyl('Clock enamel',(0,0,0),r,.04,0,20);o.rotation_euler.x=math.pi/2
 for i in range(12):
  a=i*math.tau/12;beam('Clock hour marker',(r*.75*math.sin(a),-.10,r*.75*math.cos(a)),(r*.90*math.sin(a),-.10,r*.90*math.cos(a)),.026,8)
 beam('Clock minute hand',(0,-.13,0),(.10,-.13,r*.72),.04,8);beam('Clock hour hand',(0,-.14,0),(-r*.48,-.14,-r*.2),.05,8)
 rotate_new(before,angle,(x,y,z))

def euro_tree(x,y,s=1,pink=True):
 if CITY=='rome':
  cyl('Cypress trunk',(x,y,.5*s),.08*s,1*s,5,6)
  cyl('Cypress foliage',(x,y,1.3*s),.38*s,2*s,7,7,.08*s)
 else:
  cyl('Tree trunk',(x,y,.5*s),.08*s,1*s,5,6)
  ico('Clipped canopy',(x,y,1.2*s),(.62*s,.62*s,.75*s),6 if pink else 3)

def plaza(w=14,d=11,water=False):
 global category
 category='environment';box('Display plinth',(0,0,-.32),(w,d,.6),2,.18)
 box('Setting',(0,0,.01),(w-.18,d-.18,.1),3 if water else 7,.1)
 if not water:
  box('Arrival path',(0,-d*.32,.085),(2.2,d*.36,.06),1,.02)
  for i,(x,y) in enumerate([(-w*.40,-d*.33),(w*.40,-d*.33),(-w*.40,d*.34),(w*.40,d*.34)]):euro_tree(x,y,.8,i%2==0)
 category='architecture'

def big_ben():
 plaza(12,10)
 box('Elizabeth Tower base',(-2,0,.4),(2.9,2.9,.65),1)
 box('Tower sandstone shaft',(-2,0,3.7),(2.15,2.15,6.3),1)
 for side in range(4):
  a=side*math.pi/2
  for dx in [-.8,-.4,0,.4,.8]:
   x=dx*math.cos(a)+1.09*math.sin(a)-2;y=dx*math.sin(a)-1.09*math.cos(a)
   o=box('Vertical Gothic stone ribs',(x,y,3.6),(.065,.06,5.7),0,0);o.rotation_euler.z=a
 box('Clock chamber',(-2,0,7.05),(2.45,2.45,1.9),1)
 for side in range(4):
  a=side*math.pi/2;clockface(-2+1.26*math.sin(a),-1.26*math.cos(a),7.1,.88,a)
 for z in [6.05,8.05]:box('Clock cornice',(-2,0,z),(2.68,2.68,.17),4,.025)
 cyl('Belfry roof',(-2,0,8.62),1.65,.95,2,4,.82).rotation_euler.z=math.pi/4
 box('Lantern chamber',(-2,0,9.26),(.95,.95,.8),1)
 for x in [-2.36,-1.64]:box('Lantern louvers',(x,-.49,9.26),(.18,.04,.55),8,0)
 cyl('Steep tower spire',(-2,0,10.26),.88,1.35,2,4,0).rotation_euler.z=math.pi/4
 cyl('Gilt finial',(-2,0,11.12),.045,.55,4,6,0)
 # Compact Palace of Westminster wing as context, still recognizable from the river.
 box('Parliament wing',(1.9,.8,1.7),(5.6,3.2,3.0),1);roof('Palace slate roof',1.9,.8,3.2,5.8,3.4,.85)
 for x in [0,.8,1.6,2.4,3.2,4]:
  arched_window(x,-.83,.75,.42,1.8,2,True)
  cyl('Palace pinnacle',(x,-.8,3.6),.12,.9,0,5,0)

def tower_bridge():
 plaza(20,9,True)
 box('Bridge road',(0,0,1.05),(18,1.55,.28),2)
 for x in [-4,4]:
  box('River pier',(x,0,.25),(3,3,.45),1,.2)
  # Open road passage through tower, not a solid block.
  before=set(cur.objects);arch('Tower roadway',0,0,.9,1.75,2.3,2.25,0,8,.7);rotate_new(before,math.pi/2,(x,0,0))
  box('Upper tower',(x,0,4.35),(2.4,2.5,2.5),0)
  for dx in [-1.0,1.0]:
   for yy in [-1.1,1.1]:
    box('Corner tower',(x+dx,yy,4.2),(.45,.45,3.8),1)
    cyl('Turret roof',(x+dx,yy,6.45),.42,.9,2,4,0).rotation_euler.z=math.pi/4
  roof('Tower pitched cap',x,0,5.6,2.6,2.7,1.05,2)
  for dx in [-.7,0,.7]:arched_window(x+dx,-1.27,3.7,.32,1.1)
 for yy in [-.85,.85]:
  box('High level walkway',(0,yy,4.85),(8,.28,.45),3)
  for k in range(11):
   x=-3.65+k*.73;beam('Walkway diagonal',(x,yy-.02,4.64),(x+.64,yy-.02,5.06),.055,0)
  for sign in [-1,1]:
   points=[(sign*(4+i*.6),yy,4.65-(i/8)**.52*3.35) for i in range(9)]
   for a,b in zip(points,points[1:]):beam('Blue suspension chain',a,b,.11,3)
   for x,y,z in points[1:-1]:beam('Suspension hanger',(x,y,1.2),(x,y,z),.05,0)
 # Center bascule leaves and pale safety rails.
 for yy in [-.82,.82]:beam('Deck rail',(-8.8,yy,1.5),(8.8,yy,1.5),.075,3)

def london_eye():
 plaza(12,9,True)
 box('Embankment',(0,1,.22),(10,3,.4),1,.08)
 center=Vector((0,0,5.7));radius=4.65
 for y in [-.19,.19]:ring('Wheel rim',(0,y,5.7),radius,.095,0,64,True)
 for i in range(32):
  a=i*math.tau/32;end=(radius*math.sin(a),0,5.7+radius*math.cos(a))
  beam('Tension spoke',(0,0,5.7),end,.025,1)
  x,z=(radius+.16)*math.sin(a),5.7+(radius+.16)*math.cos(a)
  o=box('Passenger capsule',(x,0,z),(.48,.65,.38),3,.09)
  ring('Capsule pale rim',(x,-.345,z),.18,.024,0,8,True)
 for x in [-2.3,2.3]:beam('A frame support',(x,1.5,.5),(0,0,5.7),.26,0)
 o=cyl('Wheel hub',(0,0,5.7),.28,.85,1,12);o.rotation_euler.x=math.pi/2
 box('Boarding pavilion',(0,.7,.7),(2.2,1.5,.75),0);roof('Pavilion canopy',0,.7,1.1,2.5,1.8,.35,3)

def st_pauls():
 plaza(14,15);box('Cathedral nave',(0,1.1,2.0),(4.4,8.5,3.6));roof('Nave roof',0,1.1,3.8,4.6,8.8,.9)
 box('Transept',(0,1,1.8),(8.4,2.5,3.3));roof('Transept roof',0,1,3.5,8.6,2.8,.7)
 cyl('Dome drum',(0,1.2,5.1),2.0,1.7,1,20)
 for i in range(20):
  a=i*math.tau/20;col(2*math.cos(a),1.2+2*math.sin(a),4.35,1.5,.12)
 cyl('Drum cornice',(0,1.2,5.94),2.18,.18,0,20);dome('Lead dome',6.03,2.1,1.85,2,(0,1.2))
 cyl('Lantern',(0,1.2,8.16),.35,.6,0,10);dome('Lantern dome',8.45,.40,.38,4,(0,1.2));cross(0,1.2,8.83,.6)
 for x in [-2.75,2.75]:
  box('West bell tower',(x,-2.7,2.7),(1.4,1.5,4.8));arched_window(x,-3.47,3.2,.6,1.25)
  cyl('Bell lantern',(x,-2.7,5.3),.55,.65,0,8);dome('Bell dome',5.65,.65,.65,2,(x,-2.7));cross(x,-2.7,6.3,.4)
 for z in [.8,2.5]:
  for x in [-1.8,-1.1,-.4,.4,1.1,1.8]:col(x,-3.6,z,1.5,.14)
 for z in [2.38,4.08]:box('West entablature',(0,-3.3,z),(4.6,1.3,.24))
 roof('West pediment',0,-3.3,4.2,4.7,1.4,.95,0);steps(6,2.5,-4.2,5)

def buckingham():
 plaza(18,12);box('Palace main block',(0,.1,2.1),(12,4.5,3.8));front_windows(12,4.5,1,3,15,y0=.1)
 box('Palace cornice',(0,.1,4.05),(12.3,4.8,.25),1);box('Slate roof',(0,.1,4.24),(11.8,4.3,.13),2)
 for x in [-5.05,0,5.05]:
  box('Projecting facade pavilion',(x,-2.3,2.25),(1.7,.55,4.0),0)
  for dx in [-.57,.57]:col(x+dx,-2.65,1.5,2.1,.13)
  box('Pavilion window',(x,-2.60,2.3),(.4,.045,.65),2,0)
  roof('Pavilion pediment',x,-2.42,4.25,1.9,.8,.45,0)
 box('Royal balcony',(0,-2.9,2.0),(2.5,.8,.18),1)
 for x in [-6.1,6.1]:box('Forecourt gatepost',(x,-4,.9),(.45,.45,1.6),0)
 for x in [-5.5,-4.8,-4.1,-3.4,-2.7,2.7,3.4,4.1,4.8,5.5]:beam('Forecourt iron rail',(x,-4,.15),(x,-4,1.45),.045,8)
 cyl('Victoria memorial plinth',(0,-4.7,.4),.8,.6,0,12);cyl('Victoria pedestal',(0,-4.7,1.2),.37,1.1,0,8);ico('Gilded victory',(0,-4.7,2.02),(.2,.2,.35),4)
 for dx in [-.23,.23]:ico('Victory wing',(dx,-4.7,2.1),(.2,.08,.3),4)

def tower_london():
 plaza(14,12)
 for x in [-4.5,4.5]:box('Curtain wall',(x,0,1),( .4,7,1.6),1)
 for y in [-3.5,3.5]:box('Curtain wall',(0,y,1),(9,.4,1.6),1);crenels(0,y,1.94,9,.4,1)
 for x in [-4.4,4.4]:
  for y in [-3.4,3.4]:cyl('Outer round tower',(x,y,1.4),.7,2.5,1,12);crenels(x,y,2.8,1.1,1.1,1)
 box('White Tower keep',(0,0,2.7),(5.3,4.4,4.8),0);box('Keep parapet',(0,0,5.14),(5.5,4.6,.22),1)
 roof('Keep pitched roof',0,0,5.25,4.8,4,.7,2)
 for x in [-2.3,2.3]:
  for y in [-1.9,1.9]:
   cyl('Keep corner turret',(x,y,5.45),.43,1.3,0,8)
   dome('Turret onion cap',6.1,.49,.52,2,(x,y));cyl('Weather vane',(x,y,6.77),.024,.3,4,6)
 front_windows(5.3,4.4,1.7,3,6)

def westminster():
 plaza(12,16);box('Abbey nave',(0,1,2.6),(3.6,9.5,4.8));roof('Abbey slate roof',0,1,5,3.8,9.7,1.25,2)
 box('West front',(0,-3.9,2.5),(5.5,.6,4.6));arched_window(0,-4.23,1.6,1.4,2.6,2,True)
 for x in [-1.95,1.95]:
  box('West Gothic tower',(x,-3.3,3.7),(1.5,1.8,7.0),0)
  for z in [3.7,5.6]:
   for dx in [-.28,.28]:arched_window(x+dx,-4.23,z,.36,1.15,2,True)
  clockface(x,-4.25,2.9,.37)
  box('Tower crown',(x,-3.3,7.27),(1.7,2,.23),1)
  for dx in [-.68,.68]:
   for dy in [-.8,.8]:cyl('Gothic pinnacle',(x+dx,-3.3+dy,7.9),.16,1,0,6,0)
 arch('Main portal',0,-4.29,.3,1.05,1.7,.15,1,6,.16)
 for x in [-2.3,2.3]:
  for y in [-1.5,0,1.5,3,4.5]:
   box('Buttress',(x,y,1.8),(.32,.3,3.4),1);beam('Flying buttress',(x,y,3.5),(x*.72,y,4.65),.19,0)
 steps(5,2,-4.75,4)

def shard():
 plaza(10,10)
 # Separate tapering glass shards with uneven open tips.
 for i in range(8):
  a=i*math.tau/8;b=(i+1)*math.tau/8;h=11.5+(i%3)*.65
  vs=[(1.6*math.cos(a),1.6*math.sin(a),.2),(1.6*math.cos(b),1.6*math.sin(b),.2),(.10*math.cos(b),.10*math.sin(b),h-.55),(.10*math.cos(a),.10*math.sin(a),h)]
  mesh('Tapered glass shard',vs,[(0,1,2,3)],3 if i%3 else 2)
  beam('Vertical shard seam',vs[0],vs[3],.045,0)
  for j in range(1,24):
   t=j/26;aa=Vector(vs[0]).lerp(Vector(vs[3]),t);bb=Vector(vs[1]).lerp(Vector(vs[2]),t);beam('Floor line',aa,bb,.018,1)
 box('Shard podium',(0,0,.35),(3.6,3.6,.35),1)

def gherkin():
 plaza(10,10);seg=20;rings=14;vs=[]
 for j in range(rings+1):
  z=.2+j*.65;r=1.05+1.15*math.sin((j/rings)*math.pi*.97)
  if j==rings:r=.05
  for i in range(seg):
   a=i*math.tau/seg+j*.075;vs.append((r*math.cos(a),r*math.sin(a),z))
 for j in range(rings):
  for i in range(seg):
   k=j*seg+i;n=j*seg+(i+1)%seg
   mesh('Diamond glass panel',[vs[k],vs[n],vs[n+seg],vs[k+seg]],[(0,1,2),(0,2,3)],2 if (i-j//2)%5==0 else 3)
   beam('Diagonal diagrid',vs[k],vs[n+seg],.026,0)
   beam('Counter diagonal',vs[n],vs[k+seg],.026,0)
 cyl('Circular base',(0,0,.22),1.22,.3,1,20)

def british():
 plaza(18,14)
 for x in [-6.1,6.1]:box('Museum side wing',(x,1,1.9),(2.5,8,3.4),0);roof('Wing roof',x,1,3.65,2.8,8.3,.55,2)
 box('Rear gallery',(0,4.15,1.9),(12,1.9,3.4),0)
 box('Front gallery',(0,-2.6,1.9),(12,2,3.4),0)
 for x in [-5.7,-5,-4.3,-3.6,-2.9,-2.2,-1.5,-.8,0,.8,1.5,2.2,2.9,3.6,4.3,5,5.7]:col(x,-3.9,.5,3.05,.14)
 box('Museum entablature',(0,-3.7,3.67),(12.4,1.2,.27));roof('Central pediment',0,-3.7,3.81,5.8,1.4,1.05,0)
 cyl('Reading room',(0,1.0,1.65),2.1,2.9,1,24);dome('Great Court glass canopy',3.12,4.1,.9,3,(0,1))
 steps(13,2,-4.2,4)

def eiffel():
 plaza(13,12)
 levels=[(.25,3.1),(1.8,2.65),(3.5,1.85),(5.35,1.08),(7.1,.68),(9.4,.29),(11.3,.14)]
 for sx in [-1,1]:
  for sy in [-1,1]:
   box('Stone tower footing',(sx*3.1,sy*3.1,.2),(1.1,1.1,.35),1,.06)
   for (z,r),(zz,rr) in zip(levels,levels[1:]):beam('Iron curved leg',(sx*r,sy*r,z),(sx*rr,sy*rr,zz),.20 if z<4 else .105,4)
 for z,r in [levels[2],levels[3]]:box('Observation deck',(0,0,z),(2*r+.65,2*r+.65,.22),4,.025)
 for side in range(4):
  a=side*math.pi/2
  def pt(x,y,z):return (x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a),z)
  for k,((z,r),(zz,rr)) in enumerate(zip(levels,levels[1:])):
   if k<2:continue
   subdivisions=3
   for j in range(subdivisions):
    t=j/subdivisions;u=(j+1)/subdivisions;w=r+(rr-r)*t;ww=r+(rr-r)*u;h=z+(zz-z)*t;hh=z+(zz-z)*u
    beam('Lattice X',pt(-w,-w,h),pt(ww,-ww,hh),.055,4);beam('Lattice X',pt(w,-w,h),pt(-ww,-ww,hh),.055,4)
    beam('Lattice horizontal',pt(-w,-w,h),pt(w,-w,h),.05,4)
  before=set(cur.objects);arch('Lower decorative iron arch',0,-2.55,.3,4.25,2.6,.10,4,10,.11);rotate_new(before,a)
 # Open webbing inside the four lower legs.
 for sx in [-1,1]:
  for sy in [-1,1]:
   for j in range(5):
    z=.5+j*.52;r=3.1-z*.34
    beam('Lower leg lattice',(sx*(r-.24),sy*r,z),(sx*(r+.05),sy*(r-.35),z+.5),.065,4)
 box('Top observation cabin',(0,0,11.15),(.75,.75,.38),4,.015)
 cyl('Tower antenna',(0,0,11.98),.045,1.25,4,6,0)

def arc_triomphe():
 plaza(12,10);box('Arch foundation',(0,0,.18),(7.8,4.3,.3),1,.06)
 arch('Grand passage',0,0,.3,3.25,4.9,3.2,0,10,1.15)
 for x in [-2.65,2.65]:box('Massive arch pier',(x,0,2.4),(1.85,3.26,4.2),0)
 box('Attic frieze',(0,0,6.05),(7.35,3.6,1.2),0);box('Crowning cornice',(0,0,6.76),(7.7,3.9,.25),1)
 for y in [-1.84,1.84]:
  for x in [-2.45,2.45]:
   box('Sculptural relief panel',(x,y,2.55),(1.25,.13,2.05),1,.02)
   for dx in [-.3,0,.3]:ico('Abstract relief figure',(x+dx,y*1.02,2.7+abs(dx)),(.2,.14,.48),0)
  box('Attic relief band',(0,y,6),(6.5,.08,.40),1,.01)
  for x in [-2.8,-1.85,-.92,0,.92,1.85,2.8]:ico('Carved rosette',(x,y*1.04,6),(.13,.08,.13),0)

def pyramid(n,x,y,z,w,h,sw=3,grid=0):
 v=[(x-w/2,y-w/2,z),(x+w/2,y-w/2,z),(x+w/2,y+w/2,z),(x-w/2,y+w/2,z),(x,y,z+h)]
 mesh(n,v,[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(3,2,1,0)],sw)
 if grid:
  for i in range(4):
   a,b,c=Vector(v[i]),Vector(v[(i+1)%4]),Vector(v[4]);beam('Pyramid corner',a,c,.055,0)
   for j in range(1,grid):
    t=j/grid;beam('Glass horizontal',a.lerp(c,t),b.lerp(c,t),.028,0)
    beam('Glass diagonal',a.lerp(b,t),b.lerp(c,t),.024,0)
    beam('Glass diagonal',a.lerp(b,t),a.lerp(c,1-t),.024,0)

def louvre():
 plaza(18,15)
 for x in [-6.15,6.15]:
  box('Louvre courtyard wing',(x,1.1,1.55),(2.3,8.9,2.8),0);roof('Mansard wing roof',x,1.1,3,2.5,9.1,.8,2)
  front_windows(2.3,8.9,.95,2,3,x,1.1)
  for y in [-2.5,4.6]:box('Palace pavilion',(x,y,2.0),(2.7,2.3,3.7),0);roof('Pavilion mansard',x,y,3.9,2.9,2.5,1.15,2)
 box('Rear palace gallery',(0,5,1.55),(10,1.6,2.8),0);roof('Gallery roof',0,5,3,10.2,1.8,.6)
 front_windows(10,1.6,.9,2,12,y0=5)
 pyramid('Louvre glass pyramid',0,-1,.15,5.4,3.5,3,8)
 for x,y in [(-3.5,-3.5),(3.5,-3.5),(0,3.1)]:pyramid('Satellite pyramid',x,y,.15,1.3,.85,3,3)

def notre_dame():
 plaza(13,16)
 box('Cathedral nave',(0,1.1,2.4),(4.1,9.1,4.4));roof('Long slate roof',0,1.1,4.7,4.3,9.3,1.5,2)
 box('West facade',(0,-3.8,2.25),(5.7,.5,4.1),0)
 for x in [-2,2]:
  box('Twin square tower',(x,-3.0,4.1),(1.75,2,7.8),0)
  for dx in [-.36,.36]:arched_window(x+dx,-4.025,5.2,.46,2.15,8,True)
  box('Tower flat parapet',(x,-3,8.08),(1.95,2.2,.24),1,.01)
 for x in [-1.85,0,1.85]:
  arched_window(x,-4.065,.32,1.1,1.72,8,True)
  arch('Portal archivolt',x,-4.10,.28,1.1,1.6,.12,1,6,.15)
 rose(0,-4.1,3.28,.72)
 box('Kings gallery ledge',(0,-4.08,2.24),(5.6,.35,.16),1,.01)
 for i in range(17):
  x=-2.6+i*.325;cyl('Gallery statue',(x,-4.2,2.54),.07,.35,0,6);ico('Gallery head',(x,-4.2,2.77),(.085,.07,.085),0)
 for x in [-2.85,2.85]:
  for y in [-1.6,0,1.6,3.2,4.8]:
   box('Outer buttress',(x,y,1.35),(.34,.36,2.6),1)
   beam('Flying buttress arm',(x,y,2.65),(x*.68,y,4.25),.19,0)
   cyl('Buttress pinnacle',(x,y,3.13),.16,.8,0,5,0)
 cyl('Crossing spire',(0,1.4,7.55),.40,3.1,2,8,0);cross(0,1.4,9.1,.45)

def sacre_coeur():
 plaza(13,13);steps(8,3,-4.3,6)
 box('Basilica nave',(0,.9,1.9),(5.6,5.2,3.3),0)
 for x in [-2.15,0,2.15]:
  r=.9 if x else 1.5;z=3.1 if x else 4.1
  cyl('Domed rotunda',(x,.5,z-.45),r,1.3,0,16);dome('Tall white dome',z+.2,r,1.55 if x else 2.3,0,(x,.5))
  cross(x,.5,z+(1.8 if x else 2.6),.5)
 cyl('Rear campanile',(0,2.65,4.4),.65,6.6,0,8);dome('Campanile dome',7.7,.72,1.15,0,(0,2.65));cross(0,2.65,8.85,.4)
 box('Front arcade entablature',(0,-2.55,2.3),(5.8,1.1,.25),0)
 for x in [-1.8,0,1.8]:arch('Entrance arcade',x,-2.8,.65,1.25,1.45,.55,0,8,.23)
 roof('Facade pediment',0,-2.1,2.8,3.3,1.4,1.15,0)
 rose(0,-2.83,2.95,.48)
 for x in [-2.4,2.4]:
  box('Equestrian plinth',(x,-2.4,2.95),(.65,.65,.5),0);ico('Bronze horse',(x,-2.4,3.43),(.36,.16,.25),3);ico('Mounted figure',(x,-2.4,3.78),(.12,.13,.25),3)

def invalides():
 plaza(14,12);box('Dome church',(0,.4,2),(6.8,5.8,3.6),0)
 for x in [-2.4,2.4]:roof('Side pitched roof',x,.4,3.9,2.2,5.9,.65,2)
 cyl('Octagonal drum',(0,.4,4.9),1.9,2.0,0,16)
 for i in range(16):
  a=i*math.tau/16;col(1.91*math.cos(a),.4+1.91*math.sin(a),4.05,1.7,.12)
 cyl('Gold cornice',(0,.4,5.95),2.12,.22,4,20);dome('Gilded dome',6.05,2.08,2.12,4,(0,.4))
 for i in range(12):
  a=i*math.tau/12
  for j in range(5):
   t=j*math.pi/10;u=(j+1)*math.pi/10
   beam('Gilded dome rib',(2.1*math.cos(t)*math.cos(a),.4+2.1*math.cos(t)*math.sin(a),6.05+2.14*math.sin(t)),(2.1*math.cos(u)*math.cos(a),.4+2.1*math.cos(u)*math.sin(a),6.05+2.14*math.sin(u)),.055,0)
 cyl('Dome lantern',(0,.4,8.42),.38,.65,0,10);dome('Lantern gold cap',8.75,.45,.4,4,(0,.4));cross(0,.4,9.15,.7)
 for x in [-2,-1.2,-.4,.4,1.2,2]:col(x,-2.75,.55,2.8,.15)
 box('Portico entablature',(0,-2.6,3.5),(5.3,1,.3));roof('Pediment',0,-2.6,3.65,5.4,1.1,1,0);steps(6,2,-3.5,5)

def pantheon_paris():
 plaza(14,14);box('Cruciform main hall',(0,1,2),(5.5,7,3.6),0);box('Transept',(0,1,2),(8.8,3,3.6),0)
 roof('Main slate roof',0,1,3.9,5.7,7.2,.65,2)
 cyl('Lower dome drum',(0,1,4.75),1.95,1.5,1,20)
 for i in range(20):
  a=i*math.tau/20;col(1.95*math.cos(a),1+1.95*math.sin(a),4.05,1.35,.115)
 cyl('Upper dome base',(0,1,5.53),2.08,.2,0,20);dome('Pantheon dome',5.64,1.88,1.65,2,(0,1));cyl('Lantern',(0,1,7.52),.32,.55,0,10);cross(0,1,7.84,.45)
 for x in [-2.2,-1.32,-.44,.44,1.32,2.2]:col(x,-3.3,.65,3.05,.2)
 box('Pediment support',(0,-2.95,3.8),(5.8,1.5,.28),0);roof('Sculpted pediment',0,-2.95,3.95,6,1.65,1.2,0)
 for x in [-1.8,-1.2,-.6,0,.6,1.2,1.8]:ico('Pediment sculpture',(x,-3.8,4.22),(.13,.06,.17),1)
 steps(7,2.2,-4.0,5)

def garnier():
 plaza(16,13);box('Opera main building',(0,.65,2.2),(10,6.3,4),0)
 front_windows(10,6.3,1,3,12,y0=.65)
 # Copper auditorium dome and taller stage house.
 dome('Copper auditorium dome',4.3,3.2,1.15,3,(0,.3))
 box('Stage house',(0,2.5,4.5),(5.1,2.8,3.2),1);roof('Stage roof',0,2.5,6.15,5.4,3.1,.75,2)
 box('Front entablature',(0,-2.7,4.3),(10.4,.8,.3),1)
 for x in [-3.9,-2.6,-1.3,0,1.3,2.6,3.9]:
  arched_window(x,-2.54,.4,.9,1.3,8)
  for dx in [-.4,.4]:col(x+dx,-2.85,1.95,1.8,.11)
  ring('Gilded facade medallion',(x,-2.91,3.79),.16,.045,4,10,True)
 for x in [-4.15,4.15]:
  box('Sculpture pedestal',(x,-2,4.68),(1.25,1,.5),0)
  ico('Gilded allegory',(x,-2,5.3),(.22,.20,.46),4)
  for sx in [-1,1]:ico('Gilded wing',(x+sx*.32,-2,5.4),(.34,.09,.33),4)
 box('Opera sign band',(0,-3.02,4.24),(6.7,.03,.10),4,0)
 steps(10.7,2,-3.7,4)

def pompidou():
 plaza(16,12);box('Museum glass volume',(0,.5,2.65),(10,5.4,5),3,0)
 for z in [.45,1.35,2.25,3.15,4.05,4.95,5.35]:
  box('Exposed floor structure',(0,.5,z),(10.5,5.8,.12),0,0)
 for x in [-5,-3.33,-1.66,0,1.66,3.33,5]:
  for y in [-2.4,3.4]:beam('Exoskeleton column',(x,y,.2),(x,y,5.5),.10,0)
  for y in [-2.45,3.45]:
   for z in [.45,2.25,4.05]:
    if x<4.9:beam('Exposed X brace',(x,y,z),(x+1.66,y,z+1.8),.055,0);beam('Exposed X brace',(x+1.66,y,z),(x,y,z+1.8),.055,0)
 # Signature diagonal escalator in a red tube, with cream framing.
 beam('Escalator tube',(-4.8,-2.8,.55),(4.65,-2.8,5.05),.32,5)
 for i in range(17):
  t=i/16;ring('Escalator hoop',(-4.8+9.45*t,-2.8,.55+4.5*t),.22,.035,0,8,True)
 for i,x in enumerate([3.1,3.65,4.2,4.75]):
  beam('Color coded service pipe',(x,3.62,.2),(x,3.62,5.8),.22,[3,5,4,2][i])
 for x in [-4,-2,0,2,4]:
  cyl('Roof ventilation duct',(x,.5,5.8),.25,.85,0,8)

def moulin():
 plaza(12,10);box('Cabaret base',(0,0,1.3),(8.5,3.6,2.4),5)
 box('Cream facade band',(0,-1.84,1.78),(8.7,.1,.6),0,.015)
 for x in [-3,-1.5,0,1.5,3]:arched_window(x,-1.91,.25,.9,1.35,8)
 for x in [-3.6,3.6]:box('Side cream pavilion',(x,.4,2),(1.4,3.2,3.8),0);cyl('Pavilion roof',(x,.4,4.2),1,1.3,2,4,0).rotation_euler.z=math.pi/4
 cyl('Red windmill body',(0,0,3.95),1.08,3.1,5,12,.73);cyl('Windmill cap',(0,0,5.9),1.0,1.0,5,12,0)
 ring('Windmill balcony',(0,0,3.5),1.18,.1,5,16)
 for a in [i*math.pi/2+.2 for i in range(4)]:
  start=Vector((.28*math.sin(a),-1.1,4.95+.28*math.cos(a)));end=Vector((2.65*math.sin(a),-1.1,4.95+2.65*math.cos(a)))
  beam('Windmill sail spar',start,end,.085,5)
  side=Vector((math.cos(a),0,-math.sin(a)))*.22
  beam('Sail lattice edge',start+side,end+side,.06,5);beam('Sail lattice edge',start-side,end-side,.06,5)
  for j in range(2,9):
   mid=start.lerp(end,j/9);beam('Sail crossbar',mid-side,mid+side,.045,0)
 o=cyl('Windmill hub',(0,-1.15,4.95),.25,.23,4,12);o.rotation_euler.x=math.pi/2
 # Editable, readable lettering; converted to mesh on export.
 bpy.ops.object.text_add(location=(0,-1.97,1.67),rotation=(math.pi/2,0,0));o=bpy.context.object;o.data.body='MOULIN ROUGE';o.data.align_x='CENTER';o.data.size=.39;o.data.extrude=.006
 bpy.ops.object.convert(target='MESH');finish(bpy.context.object,'Cabaret lettering',5)

def colosseum():
 plaza(16,13);sy=.74
 cyl('Arena floor',(0,0,.2),3.3,.18,1,32).scale.y=sy
 for r,z in [(4.6,1.04),(4.15,.77),(3.7,.50)]:annulus('Concentric seating tier',z,r,r-.46,.17,1,32,sy)
 for tier in range(3):
  z=.35+tier*1.35
  for i in range(28):
   a=i*math.tau/28
   if tier==2 and math.sin(a)<-.12:continue
   x=5.25*math.cos(a);y=5.25*sy*math.sin(a);angle=math.atan2(sy*math.cos(a),-math.sin(a))
   before=set(cur.objects);arch('Roman arcade',0,0,z,.78,1.05,.52,1 if tier==0 else 0,5,.18);rotate_new(before,angle,(x,y,0))
   # Applied pilaster and projecting band make the stacked orders legible.
   o=box('Arcade pilaster',(x+.56*math.cos(angle),y+.56*math.sin(angle),z+.57),(.12,.70,1.12),0,0);o.rotation_euler.z=angle
   if tier==2:
    v=[]
    for zz in [z+1.15,z+1.80]:
     for rr in [4.97,5.56]:
      for aa in [a-math.pi/28,a+math.pi/28]:v.append((rr*math.cos(aa),rr*sy*math.sin(aa),zz))
    mesh('Surviving attic',v,[(0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3)],0)
    o=box('Attic recess',(x*1.055,y*1.055,z+1.48),(.18,.035,.30),8,0);o.rotation_euler.z=a+math.pi/2
  if tier<2:annulus('Horizontal arcade cornice',z+1.13,5.62,4.92,.18,0,56,sy)
 # Uneven broken masonry at both ends of the taller surviving wall.
 for x,y,z in [(5.1,-.3,3.8),(-5.1,-.3,3.8),(-4.95,-.8,3.2)]:ico('Broken wall edge',(x,y,z),(.28,.34,.6),1)

def pantheon_rome():
 plaza(14,13);cyl('Roman brick rotunda',(0,1.1,2.1),3.75,3.8,5,32)
 for z,r in [(3.75,3.8),(4.0,3.62),(4.2,3.4)]:cyl('Stepped dome ring',(0,1.1,z),r,.20,1,32)
 # Shallow dome stops at the real oculus rather than capping it shut.
 n=32;rings=7;vs=[]
 for j in range(rings+1):
  t=j/rings*1.43
  for i in range(n):
   a=i*math.tau/n;vs.append((3.45*math.cos(t)*math.cos(a),1.1+3.45*math.cos(t)*math.sin(a),4.28+1.5*math.sin(t)))
 fs=[]
 for j in range(rings):
  for i in range(n):a=j*n+i;b=j*n+(i+1)%n;fs.append((a,b,b+n,a+n))
 mesh('Concrete dome with oculus',vs,fs,1);ring('Oculus lip',(0,1.1,5.79),.49,.055,0,24)
 for y in [-3.5,-2.6]:
  for x in [-2.8,-2,-1.2,-.4,.4,1.2,2,2.8]:
   cyl('Granite portico column',(x,y,1.65),.16,2.75,1,8,.145)
   box('Corinthian capital',(x,y,3.07),(.40,.40,.19),0,0)
 box('Portico entablature',(0,-2.9,3.3),(6.7,2.4,.40),0)
 roof('Pantheon pediment',0,-2.9,3.52,6.8,2.5,1.2,0)
 box('Bronze doorway',(0,-2.68,1.7),(1.45,.08,2.6),8,0);steps(7.3,1.8,-4,3)

def trevi():
 plaza(15,12)
 box('Palazzo Poli backdrop',(0,2,2.8),(11,2.9,5.3),0);front_windows(11,2.9,1.5,4,13,y0=2)
 box('Palace entablature',(0,2,5.6),(11.35,3.2,.27),1)
 for x in [-2.4,-.8,.8,2.4]:col(x,.28,1,4.2,.20)
 arched_window(0,.49,.65,2.1,3.8,8)
 for x in [-3.65,3.65]:arched_window(x,.49,1.1,1.1,2.0,8)
 box('Central attic',(0,1,6.0),(4.8,2.2,.85),0)
 for x in [-2.1,-1.1,0,1.1,2.1]:
  cyl('Attic statue',(x,.15,6.64),.11,.5,0,6);ico('Attic statue head',(x,.15,6.99),(.13,.11,.15),0)
 cyl('Fountain basin lip',(0,-1.65,.32),4.6,.35,0,32).scale.y=.62
 cyl('Turquoise basin',(0,-1.65,.52),4.32,.06,3,32).scale.y=.62
 for x,y,z,s in [(-2.5,-.15,.72,1),(2.5,-.15,.72,1),(-1.1,-.85,.8,.8),(1.1,-.85,.8,.8),(0,.1,1.05,1.1)]:ico('Travertine grotto',(x,y,z),(s,.65*s,.65*s),1)
 figure(0,-.1,.8,1.3)
 for x in [-2,2]:
  figure(x,-.7,.65,.8);ico('Sea horse',(x*.63,-1.35,.94),(.40,.25,.3),0)
  beam('Water cascade',(x,.12,.72),(x,-1.6,.54),.17,3)

def spanish():
 plaza(13,16)
 # Three linked flights, split in the middle around the planted terrace.
 for i in range(9):
  y=-4.5+i*.43;z=.22+i*.15
  box('Lower sweeping stair',(0,y,(z+.1)/2),(7.7-abs(i-4)*.26,2.1,z+.1),0,.015)
 box('Middle garden terrace',(0,.05,1.52),(2.9,2.4,.3),7,.05)
 for side in [-1,1]:
  for i in range(7):box('Split middle stair',(side*(2.15-i*.06),-.3+i*.43,(1.66+i*.16)/2),(2.1,1.45,1.66+i*.16),0,.01)
 for i in range(5):box('Upper stair',(0,2.5+i*.35,(2.76+i*.14)/2),(6.0-i*.12,1.6,2.76+i*.14),0,.01)
 for x in [-3.6,3.6]:beam('Stair balustrade',(x,-4.6,.7),(x*.75,3.5,3.5),.15,1)
 box('Trinita dei Monti',(0,4.8,4.7),(4.4,2.0,2.5),0);roof('Church roof',0,4.8,6,4.5,2.2,.6,5)
 for x in [-1.65,1.65]:
  box('Twin bell tower',(x,4.35,5.8),(1.05,1.2,4.0),0);arched_window(x,3.72,6.6,.45,.85)
  cyl('Bell tower cap',(x,4.35,8.03),.71,.7,1,4,0).rotation_euler.z=math.pi/4;cross(x,4.35,8.38,.35)
 roof('Church front pediment',0,3.85,5.6,2.7,.3,.65,0)
 arched_window(0,3.775,3.5,.75,1.35,8)
 box('Church raised foundation',(0,4.8,1.75),(4.4,2,3.45),1,.02)
 cyl('Sallustian obelisk',(0,3.0,4.55),.23,2.6,1,4,.12).rotation_euler.z=math.pi/4
 cyl('Obelisk pyramidion',(0,3,6.0),.12,.30,1,4,0).rotation_euler.z=math.pi/4
 cyl('Barcaccia basin',(0,-5.85,.24),1.18,.2,1,16).scale.y=.5
 ico('Boat fountain',(0,-5.85,.39),(1.0,.39,.18),0)

def castel():
 plaza(14,14)
 box('Fortress square base',(0,.8,.5),(8,7,0.8),1,.15)
 for x in [-3.9,3.9]:
  for y in [-2.6,4.2]:cyl('Corner bastion',(x,y,.8),.9,1.3,1,8)
 cyl('Hadrian mausoleum drum',(0,.8,2.3),3.65,3.6,1,32)
 cyl('Brick upper drum',(0,.8,4.25),3.6,.55,5,32)
 annulus('Terrace parapet',4.52,3.69,3.38,.25,0,32).location.y=.8
 for i in range(24):
  a=i*math.tau/24;x=3.62*math.cos(a);y=.8+3.62*math.sin(a)
  o=box('Parapet merlon',(x,y,4.94),(.33,.28,.46),1,0);o.rotation_euler.z=a
 box('Papal apartments',(0,1,5.22),(3.9,2.7,1.2),0);front_windows(3.9,2.7,5.2,1,5,0,1)
 roof('Apartment terracotta roof',0,1,5.88,4.1,2.9,.50,5)
 cyl('Angel pedestal',(0,1,6.55),.3,.7,1,8);ico('Angel figure',(0,1,7.12),(.15,.15,.35),3)
 for x in [-.27,.27]:ico('Angel wing',(x,1,7.27),(.26,.09,.30),3)
 # Short approach bridge, with actual arches beneath the deck.
 box('Ponte approach',(0,-4.4,.66),(2.1,4.6,.3),0)
 for y in [-5.8,-4.5]:
  before=set(cur.objects);arch('Bridge arch',0,0,.08,.8,.55,2.1,1,5,.12);rotate_new(before,math.pi/2,(0,y,0))
 for x in [-1,1]:
  beam('Bridge balustrade',(x,-6.4,1.2),(x,-2.4,1.2),.09,0)
  for y in [-5.9,-4.6,-3.3]:cyl('Bridge angel pedestal',(x,y,1.17),.15,.7,0,6);ico('Bridge angel',(x,y,1.72),(.12,.12,.28),0)

def st_peters():
 plaza(18,18)
 box('Basilica nave',(0,3,2.1),(6,7.8,3.7),0);roof('Nave roof',0,3,4,6.3,8,.65,2)
 box('Maderno facade',(0,-.65,2.0),(10.1,2.1,3.6),0)
 for x in [-4.3,-3.25,-2.2,-1.15,0,1.15,2.2,3.25,4.3]:
  col(x,-1.77,.45,3.2,.17);arched_window(x,-1.72,.55,.58,1.7,8)
 box('Facade entablature',(0,-.65,3.98),(10.5,2.4,.30),1)
 roof('Central facade pediment',0,-.65,4.14,3.5,2.4,.65,0)
 for x in [-4.5,-3.75,-3,-2.25,-1.5,-.75,0,.75,1.5,2.25,3,3.75,4.5]:
  cyl('Roof saint',(x,-1.55,4.55),.09,.40,0,6);ico('Saint head',(x,-1.55,4.83),(.11,.1,.12),0)
 cyl('Dome drum',(0,3.1,5.1),2.0,1.8,0,20)
 for i in range(16):
  a=i*math.tau/16;col(2.01*math.cos(a),3.1+2.01*math.sin(a),4.35,1.45,.11)
 dome('Michelangelo dome',6.0,2.08,2.45,2,(0,3.1));cyl('Dome lantern',(0,3.1,8.7),.32,.6,0,10);dome('Lantern cap',9.0,.40,.35,4,(0,3.1));cross(0,3.1,9.35,.5)
 # Two open arms of Bernini's colonnade; simplified to a single column rank.
 for sign in [-1,1]:
  pts=[]
  for i in range(18):
   a=-1.2+i*2.4/17;x=sign*(4.3+1.9*math.cos(a));y=-4.6+2.7*math.sin(a)
   col(x,y,.23,1.75,.13);pts.append((x,y,2.06))
  for a,b in zip(pts,pts[1:]):beam('Colonnade roof',a,b,.30,0)
 cyl('Square obelisk',(0,-4.9,1.5),.23,2.6,1,4,.13).rotation_euler.z=math.pi/4
 cyl('Obelisk tip',(0,-4.9,2.95),.13,.3,1,4,0).rotation_euler.z=math.pi/4
 for x in [-2.4,2.4]:cyl('Square fountain',(x,-4.9,.3),.65,.35,0,16);cyl('Fountain water',(x,-4.9,.5),.52,.08,3,16)

def forum():
 plaza(15,12);box('Temple of Saturn podium',(0,0,.6),(7,4.4,.9),1,.08);steps(6,2,-2.8,5)
 # Eight standing columns: six at front and two returns, with surviving entablature.
 for x in [-2.65,-1.59,-.53,.53,1.59,2.65]:col(x,-1.3,1.1,3.9,.22)
 for x in [-2.65,2.65]:col(x,.4,1.1,3.9,.22);box('Return entablature',(x,-.45,5.16),(.7,2.4,.43),0,.025)
 box('Surviving temple entablature',(0,-1.3,5.16),(6.2,.75,.5),0,.035)
 for x,z in [(-2,1.1),(1.8,.9),(3.9,.65),(-4.1,.7)]:
  o=cyl('Fallen column drum',(x,1.4,z),.24,1.15,1,8);o.rotation_euler.y=math.pi/2
 for i in range(12):
  x=random.uniform(-5.2,5.2);y=random.uniform(-.1,3.7)
  ico('Scattered masonry',(x,y,.24),(random.uniform(.2,.5),.22,.18),1)
 # Temple footprint and fragments establish this as a ruin, not a complete temple.
 for y in [1.1,2.0]:box('Exposed foundation',(0,y,1.12),(5.6,.30,.25),1,.02)

def horse(x,y,z,s=1,sw=3):
 ico('Horse body',(x,y,z+.55*s),(.65*s,.23*s,.35*s),sw)
 ico('Horse neck',(x+.42*s,y,z+.87*s),(.18*s,.18*s,.4*s),sw)
 ico('Horse head',(x+.54*s,y,z+1.12*s),(.25*s,.16*s,.18*s),sw)
 for dx in [-.36,.34]:
  for dy in [-.17,.17]:beam('Horse leg',(x+dx*s,y+dy*s,z+.45*s),(x+dx*s,y+dy*s,z),.09*s,sw)
 ico('Rider',(x-.02*s,y,z+1.10*s),(.15*s,.17*s,.33*s),sw)

def vittoriano():
 plaza(18,14)
 for i in range(10):box('Monument stair terrace',(0,-2+i*.38,.25+i*.19),(12.5-i*.33,5-i*.34,.25),0,.02)
 box('Upper terrace',(0,2.3,2.25),(12,4.7,.4),0)
 box('Terrace substructure',(0,2.3,1.1),(11.8,4.5,2),1,.02)
 # Broad gently curving colonnade.
 pts=[]
 for i in range(17):
  x=-5.2+i*.65;y=2.8+.035*x*x;col(x,y,2.45,2.65,.16);pts.append((x,y,5.24))
 for a,b in zip(pts,pts[1:]):beam('Curved entablature',a,b,.42,0)
 for x in [-5.6,5.6]:
  for dx in [-.6,.6]:
   for y in [2.4,3.8]:col(x+dx,y,2.45,2.7,.17)
  box('Quadriga pavilion roof',(x,3.1,5.38),(2,2,.35),0)
  horse(x,3.1,5.62,.66,3)
  ico('Winged victory',(x-.6,3.1,6.0),(.13,.16,.3),3)
  cyl('Victory base',(x-.6,3.1,5.7),.12,.28,3,6)
 cyl('Equestrian pedestal',(0,-.35,2.0),.8,1.2,1,8)
 horse(0,-.35,2.61,1.3,3)
 for x in [-4.8,4.8]:
  cyl('Italian flagpole',(x,-2.7,2),.032,3.4,4,6)
  for i,sw in enumerate([7,0,5]):box('Italian tricolor',(x+.17+i*.22,-2.7,3.35),(.22,.025,.43),sw,0)

def navona():
 plaza(12,12)
 cyl('Four Rivers basin rim',(0,0,.27),3.4,.32,0,32).scale.y=.78
 cyl('Fountain water',(0,0,.46),3.13,.06,3,32).scale.y=.78
 for x,y in [(-.75,-.5),(.75,-.5),(-.65,.6),(.65,.6)]:ico('Travertine rock',(x,y,1.05),(.85,.65,1.0),1)
 # Four abstract river gods around the rock, kept deliberately low detail.
 for i in range(4):
  a=i*math.pi/2;x=1.35*math.cos(a);y=1.35*math.sin(a)
  ico('Reclining river god',(x,y,.89),(.32,.4,.50),0);ico('River god head',(x,y,1.42),(.19,.19,.23),0)
  beam('Reclining leg',(x,y,.65),(x*1.5,y*1.5,.55),.20,0)
 cyl('Obelisk pedestal',(0,0,1.85),.65,.6,0,4).rotation_euler.z=math.pi/4
 cyl('Agonal obelisk',(0,0,4.45),.41,4.8,1,4,.21).rotation_euler.z=math.pi/4
 cyl('Obelisk pyramidion',(0,0,7.04),.21,.38,1,4,0).rotation_euler.z=math.pi/4
 ico('Dove finial',(0,0,7.37),(.17,.12,.12),4)
 for z in [2.6,3.2,3.8,4.4,5.0,5.6,6.2]:box('Abstract carved glyph',(0,-(.34-(z-2.6)*.028),z),(.12,.02,.22),0,0)

def cestius():
 plaza(12,11);box('Pyramid foundation',(0,0,.22),(6.9,6.9,.32),1,.08)
 pyramid('Marble pyramid',0,0,.38,6.2,7.4,0)
 # Restrained masonry courses, mapped to the front slope.
 for i in range(1,13):
  z=.38+i*.49;t=(z-.38)/7.4;w=6.2*(1-t);y=-3.1*(1-t)-.012
  beam('Marble course',(-w/2,y,z),(w/2,y,z),.016,1)
 # Adjacent Aurelian wall, abbreviated as context.
 box('Aurelian wall',(3.65,2.2,1.15),(2.3,.6,2.1),5,.03);crenels(3.65,2.2,2.33,2.3,.6,5)
