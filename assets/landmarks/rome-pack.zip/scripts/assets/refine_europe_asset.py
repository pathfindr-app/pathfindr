"""Rebuild only selected assets inside a completed city library; preserve the rest."""
import bpy,math,random,json,sys,argparse
from pathlib import Path
from mathutils import Vector
p=argparse.ArgumentParser();p.add_argument('--city',required=True);p.add_argument('--assets',required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:])
CITY=a.city;R=Path(__file__).resolve().parents[2]/'assets/landmarks'/CITY
bpy.ops.wm.open_mainfile(filepath=str(R/f'{CITY}.blend'))
mat=bpy.data.materials['Pathfindr | matte painted ceramic'];category='architecture';cur=None
source=Path(__file__).with_name('build_europe_landmarks.py').read_text();exec(source[source.index('def finish('):])
# Same functions as the main runner, selected by manifest id.
functions={'arc-de-triomphe':'arc_triomphe','colosseum':'colosseum','eiffel-tower':'eiffel','tower-bridge':'tower_bridge','big-ben':'big_ben','london-eye':'london_eye','st-pauls':'st_pauls','buckingham-palace':'buckingham','tower-of-london':'tower_london','westminster-abbey':'westminster','the-shard':'shard','the-gherkin':'gherkin','british-museum':'british','louvre':'louvre','notre-dame':'notre_dame','sacre-coeur':'sacre_coeur','les-invalides':'invalides','pantheon-paris':'pantheon_paris','palais-garnier':'garnier','centre-pompidou':'pompidou','moulin-rouge':'moulin','pantheon-rome':'pantheon_rome','trevi-fountain':'trevi','spanish-steps':'spanish','castel-sant-angelo':'castel','st-peters':'st_peters','roman-forum':'forum','vittoriano':'vittoriano','piazza-navona':'navona','pyramid-cestius':'cestius'}
manifest=json.loads((R/'manifest.json').read_text());scene=bpy.context.scene;cam=scene.camera;oldcam=cam.matrix_world.copy();oldscale=cam.data.ortho_scale
for slug in a.assets.split(','):
 i=next(i for i,item in enumerate(manifest['assets']) if item['id']==slug);record=manifest['assets'][i]
 cur=bpy.data.collections[slug];cur.hide_render=False;cur.hide_viewport=False
 for o in list(cur.objects):bpy.data.objects.remove(o,do_unlink=True)
 random.seed(92);category='architecture';globals()[functions[slug]]()
 for diorama in [True,False]:
  bpy.ops.object.select_all(action='DESELECT')
  for o in cur.objects:o.select_set(diorama or o.get('asset_part')=='architecture')
  bpy.context.view_layer.objects.active=next(o for o in cur.objects if o.select_get());bpy.ops.object.duplicate();bpy.ops.object.join();merged=bpy.context.object;merged.name=slug
  scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
  path=R/record['diorama' if diorama else 'file'];bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_yup=True,export_apply=True)
  merged.data.calc_loop_triangles();record['dioramaTriangles' if diorama else 'triangles']=len(merged.data.loop_triangles)
  if diorama:record['dimensionsBlender']=list(merged.dimensions)
  else:record['bytes']=path.stat().st_size
  bpy.data.objects.remove(merged,do_unlink=True)
 for c in bpy.data.collections:c.hide_render=c.name not in [slug,'STUDIO','Collection'];c.hide_viewport=c.hide_render
 w,d,h=record['dimensionsBlender'];target=Vector((0,0,max(1.2,h*.32)));cam.location=target+Vector((14,-23,17));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=max(w*1.32,d*1.26,h*1.58)
 scene.render.filepath=str(R/record['preview']);bpy.ops.render.render(write_still=True)
 for o in cur.objects:o.location+=Vector(((i%5-2)*24,(i//5)*24,0))
 for c in bpy.data.collections:c.hide_render=False;c.hide_viewport=False
cam.matrix_world=oldcam;cam.data.ortho_scale=oldscale
bpy.ops.wm.save_as_mainfile(filepath=str(R/f'{CITY}.blend'));(R/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
